package com.attcs.service;

import com.attcs.model.Route;
import com.attcs.model.Station;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * ═══════════════════════════════════════════════════
 * ATTCS AI — Route Optimizer (Pure Java)
 * Multi-objective BFS pathfinding with AI scoring.
 * Mirrors: ai-engine/ai_optimizer.py
 * ═══════════════════════════════════════════════════
 */
@Service
public class AiOptimizerService {

    private final NetworkService networkService;

    // Speed profiles (km/h) — same as Python
    private static final Map<String, Integer> SPEED = Map.of(
        "ice", 280,
        "ic",  200,
        "re",  120
    );

    // Energy consumption (kWh/km) — same as Python
    private static final Map<String, Double> ENERGY = Map.of(
        "ice", 0.80,
        "ic",  0.55,
        "re",  0.35
    );

    // Adjacency graph: stationId → list of [neighborId, type, distanceKm]
    private final Map<String, List<int[]>> graph = new HashMap<>();
    // stationId → index in route list for quick type/dist lookup
    private final Map<String, List<Object[]>> adjFull = new HashMap<>();

    public AiOptimizerService(NetworkService networkService) {
        this.networkService = networkService;
    }

    @PostConstruct
    public void buildGraph() {
        for (Route r : networkService.getRoutes()) {
            adjFull.computeIfAbsent(r.getFrom(), k -> new ArrayList<>())
                   .add(new Object[]{r.getTo(), r.getType(), r.getDistance()});
            adjFull.computeIfAbsent(r.getTo(), k -> new ArrayList<>())
                   .add(new Object[]{r.getFrom(), r.getType(), r.getDistance()});
        }
    }

    /**
     * Find and rank the top 3 optimal routes between two stations.
     * Mirrors RouteOptimizer.optimize() in Python.
     */
    public List<Map<String, Object>> optimize(String origin, String destination, String priority) {
        if (origin == null || destination == null) return fallbackRoutes(priority);

        List<PathResult> allPaths = findAllPaths(origin, destination, 6);
        if (allPaths.isEmpty()) return fallbackRoutes(priority);

        // Score each path
        List<ScoredRoute> scored = new ArrayList<>();
        for (PathResult p : allPaths) {
            scored.add(scorePath(p, priority));
        }

        // Sort descending by score (highest = best)
        scored.sort((a, b) -> Double.compare(b.score, a.score));

        // Build top 3 route result maps
        List<Map<String, Object>> routes = new ArrayList<>();
        String[] routeNameTemplates = {"Direct High-Speed", null, "Alternative Route"};
        Map<String, String> priorityTags = Map.of(
            "fastest",  "AI Recommended — Fastest",
            "energy",   "Most Energy Efficient",
            "capacity", "Max Capacity Available",
            "conflict", "Least Conflicts"
        );

        for (int i = 0; i < Math.min(3, scored.size()); i++) {
            ScoredRoute s = scored.get(i);
            boolean recommended = (i == 0);

            String name;
            if (i == 0) {
                name = "Direct High-Speed";
            } else if (i == 1 && s.pathNodes.size() > 1) {
                Station mid = networkService.findStation(s.pathNodes.get(1));
                String midName = mid != null ? mid.getName().replace(" Hbf", "") : "Junction";
                name = "Via " + midName;
            } else {
                name = "Alternative Route";
            }

            int hours = s.timeMin / 60;
            int mins  = s.timeMin % 60;

            Map<String, Object> route = new LinkedHashMap<>();
            route.put("name",        name);
            route.put("recommended", recommended);
            route.put("tag",         recommended ? priorityTags.getOrDefault(priority, "AI Recommended") : null);
            route.put("duration",    String.format("%dh %02dm", hours, mins));
            route.put("distance",    s.distance + " km");
            route.put("stops",       s.stops);
            route.put("speed",       "Avg " + s.avgSpeed + " km/h");
            route.put("energy",      s.energy + " kWh");
            route.put("conflicts",   s.conflicts);
            route.put("capacity",    s.capacity + "%");
            route.put("ai_score",    Math.round(s.score * 10.0) / 10.0);
            route.put("path",        stationNames(s.pathNodes));
            routes.add(route);
        }
        return routes;
    }

    // ── BFS: find all paths up to maxDepth hops ──────────────────────────────

    private List<PathResult> findAllPaths(String origin, String destination, int maxDepth) {
        List<PathResult> results = new ArrayList<>();
        Deque<PathState> queue = new ArrayDeque<>();
        queue.add(new PathState(origin, List.of(origin), new ArrayList<>(), 0));

        while (!queue.isEmpty() && results.size() < 10) {
            PathState cur = queue.poll();
            if (cur.node.equals(destination) && cur.path.size() > 1) {
                results.add(new PathResult(cur.path, cur.edges, cur.totalDist));
                continue;
            }
            if (cur.path.size() > maxDepth) continue;

            List<Object[]> neighbors = adjFull.getOrDefault(cur.node, Collections.emptyList());
            for (Object[] nb : neighbors) {
                String nbId   = (String) nb[0];
                String type   = (String) nb[1];
                int    dist   = (int)    nb[2];
                if (!cur.path.contains(nbId)) {
                    List<String> newPath  = new ArrayList<>(cur.path);
                    newPath.add(nbId);
                    List<EdgeInfo> newEdges = new ArrayList<>(cur.edges);
                    newEdges.add(new EdgeInfo(cur.node, nbId, type, dist));
                    queue.add(new PathState(nbId, newPath, newEdges, cur.totalDist + dist));
                }
            }
        }
        return results;
    }

    // ── Scoring ───────────────────────────────────────────────────────────────

    private ScoredRoute scorePath(PathResult p, String priority) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        int totalTimeMin   = 0;
        double totalEnergy = 0;

        for (EdgeInfo e : p.edges) {
            int    speed  = SPEED.getOrDefault(e.type, 120);
            double energy = ENERGY.getOrDefault(e.type, 0.5);
            totalTimeMin   += (int) Math.round((e.dist / (double) speed) * 60);
            totalEnergy    += e.dist * energy;
        }

        int stops    = p.nodes.size() - 2;
        int avgSpeed = totalTimeMin > 0 ? (int)(p.totalDist / (totalTimeMin / 60.0)) : 0;
        int conflicts = Math.max(0, stops - 2) + rnd.nextInt(2);
        int capacity  = 40 + rnd.nextInt(46);

        double score;
        switch (priority == null ? "fastest" : priority) {
            case "energy"   -> score = 1000 - totalEnergy * 2;
            case "capacity" -> score = 1000 - capacity * 5.0;
            case "conflict" -> score = 1000 - conflicts * 100.0;
            default         -> score = 1000 - totalTimeMin * 3.0;
        }

        ScoredRoute sr = new ScoredRoute();
        sr.pathNodes = p.nodes;
        sr.timeMin   = totalTimeMin;
        sr.distance  = p.totalDist;
        sr.energy    = (int) Math.round(totalEnergy);
        sr.avgSpeed  = avgSpeed;
        sr.stops     = Math.max(0, stops);
        sr.conflicts = conflicts;
        sr.capacity  = capacity;
        sr.score     = score;
        return sr;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private List<String> stationNames(List<String> ids) {
        List<String> names = new ArrayList<>();
        for (String id : ids) {
            Station s = networkService.findStation(id);
            names.add(s != null ? s.getName() : id);
        }
        return names;
    }

    // ── Static fallback (same as Python) ─────────────────────────────────────

    private List<Map<String, Object>> fallbackRoutes(String priority) {
        List<Map<String, Object>> routes = new ArrayList<>();

        Map<String, Object> r1 = new LinkedHashMap<>();
        r1.put("name",        "Direct High-Speed");
        r1.put("recommended", "fastest".equals(priority));
        r1.put("tag",         "fastest".equals(priority) ? "AI Recommended — Fastest" : null);
        r1.put("duration",    "2h 45m");
        r1.put("distance",    "485 km");
        r1.put("stops",       2);
        r1.put("speed",       "Avg 280 km/h");
        r1.put("energy",      "342 kWh");
        r1.put("conflicts",   0);
        r1.put("capacity",    "78%");
        r1.put("ai_score",    920.0);
        routes.add(r1);

        Map<String, Object> r2 = new LinkedHashMap<>();
        r2.put("name",        "Via Kolkata (IC)");
        r2.put("recommended", "conflict".equals(priority));
        r2.put("tag",         "conflict".equals(priority) ? "Least Conflicts" : null);
        r2.put("duration",    "3h 20m");
        r2.put("distance",    "520 km");
        r2.put("stops",       3);
        r2.put("speed",       "Avg 210 km/h");
        r2.put("energy",      "298 kWh");
        r2.put("conflicts",   0);
        r2.put("capacity",    "62%");
        r2.put("ai_score",    810.0);
        routes.add(r2);

        Map<String, Object> r3 = new LinkedHashMap<>();
        r3.put("name",        "Energy Saver Route");
        r3.put("recommended", "energy".equals(priority));
        r3.put("tag",         "energy".equals(priority) ? "Most Efficient" : null);
        r3.put("duration",    "4h 10m");
        r3.put("distance",    "490 km");
        r3.put("stops",       5);
        r3.put("speed",       "Avg 160 km/h");
        r3.put("energy",      "215 kWh");
        r3.put("conflicts",   1);
        r3.put("capacity",    "55%");
        r3.put("ai_score",    740.0);
        routes.add(r3);

        return routes;
    }

    // ── Internal data classes ─────────────────────────────────────────────────

    private record PathState(String node, List<String> path, List<EdgeInfo> edges, int totalDist) {}
    private record PathResult(List<String> nodes, List<EdgeInfo> edges, int totalDist) {}
    private record EdgeInfo(String from, String to, String type, int dist) {}

    private static class ScoredRoute {
        List<String> pathNodes;
        int timeMin, distance, energy, avgSpeed, stops, conflicts, capacity;
        double score;
    }
}
