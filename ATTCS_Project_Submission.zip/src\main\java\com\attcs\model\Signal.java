package com.attcs.model;

import jakarta.persistence.*;

/**
 * Railway signal with state (green/yellow/red/blue).
 */
@Entity
public class Signal {
    @Id
    private String id;
    private String segment;   // e.g. "DEL-BOM"
    private String state;     // "green", "yellow", "red", "blue"

    public Signal() {}

    public Signal(String id, String segment, String state) {
        this.id = id;
        this.segment = segment;
        this.state = state;
    }
    public String getSegment() { return segment; }
    public void setSegment(String segment) { this.segment = segment; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
}
