package com.attcs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * ATTCS — AI Train Traffic Control System
 * Main Spring Boot Application Entry Point
 */
@SpringBootApplication
@EnableScheduling
public class AttcsApplication {

    public static void main(String[] args) {
        SpringApplication.run(AttcsApplication.class, args);
        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  ATTCS — AI Train Traffic Control System");
        System.out.println("  Server running at http://localhost:8080");
        System.out.println("══════════════════════════════════════════════\n");
    }
}
