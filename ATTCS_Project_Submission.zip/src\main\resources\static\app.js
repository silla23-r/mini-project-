/* ═══════════════════════════════════════════════════════════════
   ATTCS — AI Train Traffic Control System
   Main Application JavaScript
   ═══════════════════════════════════════════════════════════════ */

// ══════════════════ DATA ══════════════════

const STATIONS = [
    { id: 'new_delhi', name: 'New Delhi', x: 0.65, y: 0.18 },
    { id: 'mumbai', name: 'Mumbai', x: 0.45, y: 0.10 },
    { id: 'chennai', name: 'Chennai', x: 0.60, y: 0.82 },
    { id: 'hyderabad', name: 'Hyderabad', x: 0.35, y: 0.55 },
    { id: 'bengaluru', name: 'Bengaluru', x: 0.22, y: 0.45 },
    { id: 'kolkata', name: 'Kolkata', x: 0.42, y: 0.28 },
    { id: 'ahmedabad', name: 'Ahmedabad', x: 0.40, y: 0.72 },
    { id: 'pune', name: 'Pune', x: 0.62, y: 0.35 },
    { id: 'jaipur', name: 'Jaipur', x: 0.55, y: 0.62 },
    { id: 'lucknow', name: 'Lucknow', x: 0.78, y: 0.38 },
    { id: 'surat', name: 'Surat', x: 0.18, y: 0.40 },
    { id: 'nagpur', name: 'Nagpur', x: 0.30, y: 0.15 },
];

const ROUTES = [
    { from: 'new_delhi', to: 'mumbai', type: 'ice', distance: 286 },
    { from: 'new_delhi', to: 'kolkata', type: 'ice', distance: 253 },
    { from: 'new_delhi', to: 'pune', type: 'ice', distance: 187 },
    { from: 'new_delhi', to: 'lucknow', type: 'ic', distance: 193 },
    { from: 'mumbai', to: 'kolkata', type: 'ice', distance: 150 },
    { from: 'mumbai', to: 'nagpur', type: 'ic', distance: 119 },
    { from: 'kolkata', to: 'bengaluru', type: 'ice', distance: 284 },
    { from: 'kolkata', to: 'hyderabad', type: 'ice', distance: 355 },
    { from: 'bengaluru', to: 'hyderabad', type: 'ice', distance: 189 },
    { from: 'bengaluru', to: 'surat', type: 'ic', distance: 40 },
    { from: 'hyderabad', to: 'ahmedabad', type: 'ice', distance: 210 },
    { from: 'hyderabad', to: 'jaipur', type: 'ice', distance: 226 },
    { from: 'ahmedabad', to: 'chennai', type: 'ice', distance: 234 },
    { from: 'jaipur', to: 'chennai', type: 'ice', distance: 171 },
    { from: 'jaipur', to: 'pune', type: 'ic', distance: 278 },
    { from: 'pune', to: 'lucknow', type: 're', distance: 120 },
    { from: 'nagpur', to: 'surat', type: 're', distance: 310 },
    { from: 'kolkata', to: 'pune', type: 'ic', distance: 254 },
];

const TRAIN_NAMES = [
    'ICE 847', 'IC 204', 'ICE 72', 'IC 501', 'RE 19', 'ICE 85',
    'ICE 1523', 'IC 932', 'RE 3', 'ICE 374', 'IC 117', 'RE 42',
    'ICE 691', 'IC 813', 'RE 7', 'ICE 208', 'IC 445', 'RE 55',
    'ICE 1090', 'IC 622', 'RE 81', 'ICE 519', 'IC 306', 'RE 14',
];

function generateTrains() {
    const trains = [];
    for (let i = 0; i < TRAIN_NAMES.length; i++) {
        const name = TRAIN_NAMES[i];
        const type = name.startsWith('ICE') ? 'ice' : name.startsWith('IC ') ? 'ic' : 're';
        const routeIdx = i % ROUTES.length;
        const route = ROUTES[routeIdx];
        const progress = Math.random();
        const statuses = ['on-time', 'on-time', 'on-time', 'on-time', 'delayed', 'delayed', 'stopped'];
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const speed = status === 'stopped' ? 0 : type === 'ice' ? 180 + Math.floor(Math.random() * 120) :
            type === 'ic' ? 120 + Math.floor(Math.random() * 80) : 60 + Math.floor(Math.random() * 60);
        const delay = status === 'delayed' ? Math.floor(Math.random() * 25 + 3) : 0;
        const fromSt = STATIONS.find(s => s.id === route.from);
        const toSt = STATIONS.find(s => s.id === route.to);
        trains.push({
            id: `T${1000 + i}`,
            name,
            type,
            route: `${fromSt.name.split(' ')[0]} → ${toSt.name.split(' ')[0]}`,
            fromId: route.from,
            toId: route.to,
            progress,
            status,
            speed,
            delay,
            x: fromSt.x + (toSt.x - fromSt.x) * progress,
            y: fromSt.y + (toSt.y - fromSt.y) * progress,
            nextStation: progress > 0.5 ? toSt.name : fromSt.name,
            eta: `${Math.floor(Math.random() * 50 + 5)} min`,
            departTime: `${String(Math.floor(Math.random() * 24)).padStart(2, '0')}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`,
        });
    }
    return trains;
}

let trains = generateTrains();

// ══════════════════ JAVA API INTEGRATION ══════════════════
// Fetch live train data from Java Spring Boot backend
async function fetchTrainsFromAPI() {
    try {
        const res = await fetch('/api/trains');
        if (res.ok) {
            trains = await res.json();
            return true;
        }
    } catch(e) { /* Java backend not running, use local data */ }
    return false;
}

// Fetch live stats from Java backend
async function fetchStatsFromAPI() {
    try {
        const res = await fetch('/api/dashboard/stats');
        if (res.ok) {
            const stats = await res.json();
            document.getElementById('stat-active').textContent = stats.activeTrains;
            document.getElementById('stat-ontime').textContent = stats.onTimeRate + '%';
            document.getElementById('stat-delayed').textContent = stats.delayed;
            document.getElementById('stat-ai-decisions').textContent = stats.aiDecisions;
            document.getElementById('count-trains').textContent = stats.runningTrains;
        }
    } catch(e) { /* fallback to local */ }
}

// Fetch signals from Java backend
async function fetchSignalsFromAPI() {
    try {
        const res = await fetch('/api/signals');
        if (res.ok) {
            const data = await res.json();
            if (data.signals) {
                SIGNALS.length = 0;
                data.signals.forEach(s => SIGNALS.push(s));
            }
            return true;
        }
    } catch(e) { /* fallback */ }
    return false;
}

const SIGNALS = [];
(function generateSignals() {
    const states = ['green', 'green', 'green', 'green', 'green', 'green', 'yellow', 'yellow', 'red', 'blue'];
    for (let i = 0; i < 48; i++) {
        const route = ROUTES[i % ROUTES.length];
        SIGNALS.push({
            id: `SIG-${String(i + 1).padStart(3, '0')}`,
            segment: `${route.from.substring(0, 3).toUpperCase()}-${route.to.substring(0, 3).toUpperCase()}`,
            state: states[Math.floor(Math.random() * states.length)],
        });
    }
})();

const ALERTS = [
    {
        id: 'ALT-002',
        type: 'warning',
        badgeLabel: 'Warning',
        title: 'Weather delay — Mumbai corridor',
        desc: 'Strong crosswinds reducing max speed to 160 km/h on segments BOM-CCU.',
        time: '11 min ago',
        action: 'Monitoring',
    },
    {
        id: 'ALT-011',
        type: 'ai-resolving',
        badgeLabel: 'AI Resolving',
        title: 'Cascade delay risk — New Delhi zone',
        desc: 'AI predicting 3 cascading delays from ICE 847 delay. Rerouting IC 204.',
        time: '5 min ago',
        action: 'AI Resolving',
    },
    {
        id: 'ALT-091',
        type: 'resolved',
        badgeLabel: 'Resolved',
        title: 'Track maintenance overrun — Kolkata',
        desc: 'Maintenance completed. Track re-opened. 3 trains rescheduled by AI successfully.',
        time: '22 min ago',
        action: null,
    },
    {
        id: 'ALT-045',
        type: 'critical',
        badgeLabel: 'Critical',
        title: 'Signal failure — SIG-012',
        desc: 'Signal SIG-012 on segment HYD-AMD stuck on red. Emergency protocol triggered.',
        time: '2 min ago',
        action: 'Investigate',
    },
    {
        id: 'ALT-078',
        type: 'info',
        badgeLabel: 'Info',
        title: 'Capacity threshold — Chennai',
        desc: 'Chennai nearing 90% platform capacity. Rerouting suggestions available.',
        time: '8 min ago',
        action: 'View Options',
    },
];

const AI_ACTIONS = [
    { text: 'Recalculating <strong>ICE 847</strong> route via Pune...', progress: 72 },
    { text: 'Adjusting <strong>IC 204</strong> departure window...', progress: 45 },
    { text: 'Predicting cascade delays — <strong>Mumbai zone</strong>', progress: 88 },
    { text: 'Optimizing platform assignment — <strong>Hyderabad</strong>', progress: 30 },
];

const BOARD_TRAINS = [
    { name: 'ICE 847', chip: 'chip-ice', route: 'New Delhi → ...', depart: '23:38', delay: 14, status: 'delayed' },
    { name: 'IC 204', chip: 'chip-ic', route: 'Bengaluru → ...', depart: '23:42', delay: 3, status: 'delayed' },
    { name: 'ICE 72', chip: 'chip-ice', route: 'Hamb. → ...', depart: '23:44', delay: 0, status: 'on-time' },
    { name: 'IC 501', chip: 'chip-ic', route: 'Münch. → ...', depart: '23:48', delay: 0, status: 'on-time' },
    { name: 'RE 19', chip: 'chip-re', route: 'Frankf. →...', depart: '23:51', delay: 7, status: 'delayed' },
    { name: 'ICE 85', chip: 'chip-ice', route: 'Münch. → ...', depart: '23:58', delay: 0, status: 'on-time' },
];

const PREDICTIONS = [
    {
        type: 'delay', typeLabel: 'Delay', confidence: 87,
        title: 'ICE 1523 likely delayed at Kolkata',
        desc: 'Pattern analysis shows 87% probability of 8-12 minute delay due to converging high-speed traffic at Kolkata junction during peak hours.',
        level: 'high', pct: 87,
    },
    {
        type: 'congestion', typeLabel: 'Congestion', confidence: 74,
        title: 'Hyderabad corridor congestion expected',
        desc: 'Historical data + current load indicates congestion buildup on Hyderabad-Ahmedabad segment between 14:00-16:00.',
        level: 'medium', pct: 74,
    },
    {
        type: 'weather', typeLabel: 'Weather', confidence: 91,
        title: 'Severe storms — Northern region',
        desc: 'Weather AI model forecasts heavy storms in Mumbai-Nagpur corridor. Speed restrictions recommended from 18:00.',
        level: 'high', pct: 91,
    },
    {
        type: 'maintenance', typeLabel: 'Maintenance', confidence: 65,
        title: 'Track wear detected — Pune segment',
        desc: 'Vibration sensors indicate accelerated wear on PNQ-LKO segment. Preventive maintenance recommended within 72 hours.',
        level: 'medium', pct: 65,
    },
    {
        type: 'delay', typeLabel: 'Delay', confidence: 42,
        title: 'Minor delay risk — RE 42',
        desc: 'Low confidence prediction: RE 42 may face 3-5 min delay due to regional traffic at Surat.',
        level: 'low', pct: 42,
    },
    {
        type: 'congestion', typeLabel: 'Congestion', confidence: 82,
        title: 'Chennai platform overload',
        desc: 'AI suggests Chennai main station will hit 95% capacity at 17:00. Recommend pre-emptive rerouting of 2 regional trains.',
        level: 'high', pct: 82,
    },
];

const DISPATCH_QUEUE = [
    { train: 'ICE 1523', detail: 'Kolkata → Hyderabad — Awaiting platform', priority: 'high', status: 'processing' },
    { train: 'IC 932', detail: 'Bengaluru → Ahmedabad — Route conflict', priority: 'high', status: 'queued' },
    { train: 'RE 3', detail: 'Nagpur → Surat — Scheduled', priority: 'low', status: 'dispatched' },
    { train: 'ICE 374', detail: 'New Delhi → Chennai — Express priority', priority: 'medium', status: 'processing' },
    { train: 'IC 117', detail: 'Pune → Jaipur — Standard', priority: 'low', status: 'queued' },
    { train: 'RE 42', detail: 'Lucknow → Pune — Regional', priority: 'low', status: 'dispatched' },
    { train: 'ICE 691', detail: 'Mumbai → New Delhi — Delayed reroute', priority: 'high', status: 'processing' },
];

const DECISION_LOG = [
    { time: '23:45:12', text: 'Reduced speed limit on <span class="highlight">BOM-CCU</span> segment to 160 km/h due to crosswind advisory.' },
    { time: '23:44:30', text: 'Rerouted <span class="highlight">ICE 847</span> via Pune to avoid signaling issue at New Delhi south junction.' },
    { time: '23:43:55', text: 'Swapped platform assignment for <span class="highlight">IC 204</span> at Bengaluru — Platform 3 → Platform 7.' },
    { time: '23:42:18', text: 'Extended dwell time for <span class="highlight">RE 19</span> at Hyderabad by 4 minutes to allow passenger transfer.' },
    { time: '23:41:02', text: 'Initiated cascade delay prevention: adjusted departure windows for 3 trains in <span class="highlight">Mumbai zone</span>.' },
    { time: '23:39:45', text: 'Cleared signal <span class="highlight">SIG-028</span> after automated safety check passed.' },
    { time: '23:38:12', text: 'AI confidence for <span class="highlight">ICE 1523</span> delay prediction increased to 87%. Proactive reroute prepared.' },
    { time: '23:36:50', text: 'Assigned <span class="highlight">ICE 85</span> to high-speed track segment MAA-JAI for on-time performance.' },
];

const RESCHEDULE_ITEMS = [
    { train: 'ICE 847', detail: 'Original dep 23:24 → rescheduled to 23:38. Rerouted via Pune.', time: '23:20' },
    { train: 'IC 204', detail: 'Departure adjusted by +3 min to avoid platform conflict at Bengaluru.', time: '23:35' },
    { train: 'RE 19', detail: 'Held at Hyderabad for 4 min. Connection preserved for IC 501.', time: '23:40' },
    { train: 'ICE 374', detail: 'Fast-tracked to express priority. ETA Chennai improved by 8 min.', time: '23:15' },
    { train: 'IC 932', detail: 'Route changed: Bengaluru → Kolkata → Ahmedabad (avoiding Hyderabad congestion).', time: '23:28' },
    { train: 'RE 42', detail: 'No changes needed. AI confirmed on-time status.', time: '23:32' },
    { train: 'ICE 691', detail: 'Rerouted via Kolkata due to signal failure on direct New Delhi-Mumbai track.', time: '23:10' },
];

const MAINTENANCE_ITEMS = [
    { title: 'Track Inspection — PNQ-LKO Segment', desc: 'Routine rail inspection and wear measurement', date: '2026-04-19', status: 'scheduled', type: 'scheduled' },
    { title: 'Signal Repair — SIG-012', desc: 'Emergency repair of stuck signal at Hyderabad-Ahmedabad', date: '2026-04-18', status: 'in-progress', type: 'urgent' },
    { title: 'Switch Mechanism — Kolkata Jct', desc: 'Preventive maintenance of junction switch #4', date: '2026-04-20', status: 'scheduled', type: 'scheduled' },
    { title: 'Overhead Wire — Mumbai-Nagpur', desc: 'Catenary wire tension adjustment after storm', date: '2026-04-18', status: 'in-progress', type: 'in-progress' },
    { title: 'Platform Resurfacing — Bengaluru P3', desc: 'Surface repair and marking renewal', date: '2026-04-17', status: 'completed', type: 'completed' },
    { title: 'Brake System — ICE Fleet #8', desc: 'Scheduled brake pad replacement for ICE fleet unit 8', date: '2026-04-21', status: 'scheduled', type: 'scheduled' },
    { title: 'Track Bed Stabilization — MAA-JAI', desc: 'Ballast tamping and realignment', date: '2026-04-22', status: 'scheduled', type: 'scheduled' },
    { title: 'Signal Calibration — New Delhi South', desc: 'Full recalibration of 6 signals at New Delhi south junction', date: '2026-04-16', status: 'completed', type: 'completed' },
];

const CAPACITY_SEGMENTS = [
    { name: 'New Delhi', usage: 78 },
    { name: 'Mumbai', usage: 65 },
    { name: 'Chennai', usage: 91 },
    { name: 'Hyderabad', usage: 84 },
    { name: 'Bengaluru', usage: 58 },
    { name: 'Kolkata', usage: 72 },
    { name: 'Ahmedabad', usage: 45 },
    { name: 'Pune', usage: 52 },
    { name: 'Jaipur', usage: 38 },
    { name: 'DEL-BOM Track', usage: 70 },
    { name: 'HYD-AMD Track', usage: 88 },
    { name: 'BOM-CCU Track', usage: 55 },
];


// ══════════════════ INITIALIZATION ══════════════════

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initClock();
    initNetworkMap();
    populateAlerts();
    populateTrainBoard();
    populateAIActions();
    populateTrainPositions();
    populateSignalGrid();
    populateDispatch();
    populateDecisionLog();
    populatePredictions();
    populateRescheduleTimeline();
    populateSignalControl();
    populateCapacity();
    populateMaintenance();
    initRouteOptimizer();
    initTracker();
    startLiveUpdates();
});


// ══════════════════ NAVIGATION ══════════════════

function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');
    const sidebar = document.getElementById('sidebar');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;

            navItems.forEach(n => n.classList.remove('active'));
            item.classList.add('active');

            pages.forEach(p => p.classList.remove('active'));
            const target = document.getElementById('page-' + page);
            if (target) target.classList.add('active');

            if (window.innerWidth <= 900) {
                sidebar.classList.remove('open');
            }

            // Resize canvas when switching to dashboard
            if (page === 'dashboard') {
                setTimeout(() => resizeCanvas(), 100);
            }
            if (page === 'capacity') {
                setTimeout(() => drawCapacityChart(), 200);
            }
        });
    });

    // Hamburger buttons
    document.getElementById('hamburger-btn').addEventListener('click', toggleSidebar);
    document.querySelectorAll('.page-hamburger').forEach(btn => {
        btn.addEventListener('click', toggleSidebar);
    });
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (window.innerWidth <= 900) {
        sidebar.classList.toggle('open');
    } else {
        sidebar.classList.toggle('collapsed');
        setTimeout(() => resizeCanvas(), 350);
    }
}


// ══════════════════ CLOCK ══════════════════

function initClock() {
    function update() {
        const now = new Date();
        document.getElementById('clock').textContent =
            now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
    update();
    setInterval(update, 1000);
}


// ══════════════════ NETWORK MAP ══════════════════

let canvas, ctx, mapW, mapH;

function initNetworkMap() {
    canvas = document.getElementById('network-canvas');
    ctx = canvas.getContext('2d');
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Layer toggles
    document.querySelectorAll('.layer-toggle input').forEach(cb => {
        cb.addEventListener('change', () => drawMap());
    });
}

function resizeCanvas() {
    const container = document.getElementById('map-panel');
    if (!container) return;
    mapW = container.clientWidth;
    mapH = container.clientHeight;
    canvas.width = mapW * window.devicePixelRatio;
    canvas.height = mapH * window.devicePixelRatio;
    canvas.style.width = mapW + 'px';
    canvas.style.height = mapH + 'px';
    ctx.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
    drawMap();
}

function getLayerState(layer) {
    const cb = document.querySelector(`.layer-toggle input[data-layer="${layer}"]`);
    return cb ? cb.checked : true;
}

function drawMap() {
    ctx.clearRect(0, 0, mapW, mapH);

    // Background grid
    ctx.strokeStyle = 'rgba(30,41,59,0.3)';
    ctx.lineWidth = 0.5;
    const gridSize = 40;
    for (let x = 0; x < mapW; x += gridSize) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, mapH); ctx.stroke();
    }
    for (let y = 0; y < mapH; y += gridSize) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(mapW, y); ctx.stroke();
    }

    // Draw routes
    if (getLayerState('routes')) {
        ROUTES.forEach(route => {
            const from = STATIONS.find(s => s.id === route.from);
            const to = STATIONS.find(s => s.id === route.to);
            if (!from || !to) return;

            const x1 = from.x * mapW, y1 = from.y * mapH;
            const x2 = to.x * mapW, y2 = to.y * mapH;

            ctx.beginPath();
            ctx.moveTo(x1, y1);

            // Curved routes
            const midX = (x1 + x2) / 2 + (y2 - y1) * 0.15;
            const midY = (y1 + y2) / 2 - (x2 - x1) * 0.15;
            ctx.quadraticCurveTo(midX, midY, x2, y2);

            if (route.type === 'ice') {
                ctx.strokeStyle = 'rgba(255, 82, 82, 0.5)';
                ctx.lineWidth = 2.5;
                ctx.setLineDash([]);
            } else if (route.type === 'ic') {
                ctx.strokeStyle = 'rgba(0, 207, 253, 0.4)';
                ctx.lineWidth = 2;
                ctx.setLineDash([8, 4]);
            } else {
                ctx.strokeStyle = 'rgba(0, 230, 118, 0.3)';
                ctx.lineWidth = 1.5;
                ctx.setLineDash([4, 4]);
            }
            ctx.stroke();
            ctx.setLineDash([]);
        });
    }

    // Draw signals on routes
    if (getLayerState('signals')) {
        ROUTES.forEach((route, i) => {
            const from = STATIONS.find(s => s.id === route.from);
            const to = STATIONS.find(s => s.id === route.to);
            if (!from || !to) return;

            // Place signal at 30% and 70% of route
            [0.3, 0.7].forEach((t, j) => {
                const sigIdx = (i * 2 + j) % SIGNALS.length;
                const signal = SIGNALS[sigIdx];
                const sx = from.x * mapW + (to.x * mapW - from.x * mapW) * t;
                const sy = from.y * mapH + (to.y * mapH - from.y * mapH) * t;

                // Offset for curve
                const ox = (to.y * mapH - from.y * mapH) * 0.15 * (1 - Math.abs(t - 0.5) * 2);
                const oy = -(to.x * mapW - from.x * mapW) * 0.15 * (1 - Math.abs(t - 0.5) * 2);

                const fx = sx + ox;
                const fy = sy + oy;

                const colors = {
                    green: '#00E676', yellow: '#FFD600', red: '#FF5252', blue: '#00CFFD'
                };
                const color = colors[signal.state] || colors.green;

                ctx.beginPath();
                ctx.arc(fx, fy, 4, 0, Math.PI * 2);
                ctx.fillStyle = color;
                ctx.fill();
                ctx.beginPath();
                ctx.arc(fx, fy, 7, 0, Math.PI * 2);
                ctx.strokeStyle = color;
                ctx.globalAlpha = 0.3;
                ctx.lineWidth = 1;
                ctx.stroke();
                ctx.globalAlpha = 1;
            });
        });
    }

    // Draw stations
    if (getLayerState('stations')) {
        STATIONS.forEach(st => {
            const x = st.x * mapW;
            const y = st.y * mapH;

            // Outer glow
            const grad = ctx.createRadialGradient(x, y, 0, x, y, 16);
            grad.addColorStop(0, 'rgba(108, 92, 231, 0.3)');
            grad.addColorStop(1, 'rgba(108, 92, 231, 0)');
            ctx.beginPath();
            ctx.arc(x, y, 16, 0, Math.PI * 2);
            ctx.fillStyle = grad;
            ctx.fill();

            // Station dot
            ctx.beginPath();
            ctx.arc(x, y, 5, 0, Math.PI * 2);
            ctx.fillStyle = '#6C5CE7';
            ctx.fill();
            ctx.strokeStyle = '#A29BFE';
            ctx.lineWidth = 1.5;
            ctx.stroke();

            // Label
            ctx.font = '600 10px Inter, sans-serif';
            ctx.fillStyle = '#CBD5E1';
            ctx.textAlign = 'center';
            ctx.fillText(st.name.replace(' Hbf', ''), x, y - 12);
        });
    }

    // Draw trains
    if (getLayerState('trains')) {
        trains.forEach(train => {
            const x = train.x * mapW;
            const y = train.y * mapH;

            const color = train.status === 'on-time' ? '#00E676' :
                          train.status === 'delayed' ? '#FF9100' : '#FF5252';

            // Trail glow
            const tGrad = ctx.createRadialGradient(x, y, 0, x, y, 12);
            tGrad.addColorStop(0, color.replace(')', ',0.4)').replace('rgb', 'rgba'));
            tGrad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.beginPath();
            ctx.arc(x, y, 12, 0, Math.PI * 2);
            ctx.fillStyle = tGrad;
            ctx.fill();

            // Train marker
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fillStyle = color;
            ctx.fill();

            // Train label
            ctx.font = '600 8px JetBrains Mono, monospace';
            ctx.fillStyle = color;
            ctx.textAlign = 'left';
            ctx.fillText(train.name, x + 8, y + 3);
        });
    }
}


// ══════════════════ POPULATE UI ══════════════════

function populateAlerts() {
    const list = document.getElementById('alerts-list');
    list.innerHTML = ALERTS.map(a => `
        <div class="alert-card" data-id="${a.id}">
            <div class="alert-top">
                <span class="alert-badge ${a.type}">${a.badgeLabel}</span>
                <span class="alert-id">#${a.id}</span>
            </div>
            <div class="alert-title">${a.title}</div>
            <div class="alert-desc">${a.desc}</div>
            <div class="alert-footer">
                <span class="alert-time">${a.time}</span>
                ${a.action ? `<button class="alert-action-btn">${a.action}</button>` : ''}
            </div>
        </div>
    `).join('');
}

function populateTrainBoard() {
    const tbody = document.getElementById('train-board-body');
    tbody.innerHTML = BOARD_TRAINS.map(t => {
        const delayStr = t.delay > 0 ? `<span class="status-pill ${t.delay > 10 ? 'late' : 'delayed'}">+${t.delay}m</span>` :
            `<span class="status-pill on-time">On time</span>`;
        return `
        <tr>
            <td><span class="train-id-chip ${t.chip}">${t.name}</span></td>
            <td>${t.route}</td>
            <td>${t.depart}</td>
            <td>${delayStr}</td>
        </tr>`;
    }).join('');
}

function populateAIActions() {
    const list = document.getElementById('ai-actions-list');
    list.innerHTML = AI_ACTIONS.map(a => `
        <div class="ai-action-item">
            <div class="ai-action-icon">
                <svg viewBox="0 0 20 20" fill="currentColor"><path d="M13 7H7v6h6V7z"/><path fill-rule="evenodd" d="M7 2a1 1 0 012 0v1h2V2a1 1 0 112 0v1h2a2 2 0 012 2v2h1a1 1 0 110 2h-1v2h1a1 1 0 110 2h-1v2a2 2 0 01-2 2h-2v1a1 1 0 11-2 0v-1H9v1a1 1 0 11-2 0v-1H5a2 2 0 01-2-2v-2H2a1 1 0 110-2h1V9H2a1 1 0 010-2h1V5a2 2 0 012-2h2V2zM5 5h10v10H5V5z" clip-rule="evenodd"/></svg>
            </div>
            <span class="ai-action-text">${a.text}</span>
        </div>
    `).join('');
}

function populateTrainPositions() {
    const tbody = document.getElementById('train-positions-body');
    const search = document.getElementById('train-search');
    const filter = document.getElementById('status-filter');

    function render() {
        const q = search.value.toLowerCase();
        const f = filter.value;
        const filtered = trains.filter(t => {
            const matchSearch = !q || t.name.toLowerCase().includes(q) || t.id.toLowerCase().includes(q) || t.route.toLowerCase().includes(q);
            const matchFilter = f === 'all' || t.status === f;
            return matchSearch && matchFilter;
        });

        tbody.innerHTML = filtered.map(t => {
            const statusClass = t.status === 'on-time' ? 'on-time' : t.status === 'delayed' ? 'delayed' : 'late';
            const statusText = t.status === 'on-time' ? 'On Time' : t.status === 'delayed' ? `Delayed +${t.delay}m` : 'Stopped';
            return `
            <tr>
                <td><strong style="font-family:var(--font-mono)">${t.id}</strong></td>
                <td><span class="train-id-chip chip-${t.type}">${t.name}</span></td>
                <td>${t.route}</td>
                <td>${t.speed}</td>
                <td>${t.nextStation}</td>
                <td>${t.eta}</td>
                <td><span class="status-pill ${statusClass}">${statusText}</span></td>
                <td><button class="action-btn" onclick="openTracker('${t.id}')">Track</button></td>
            </tr>`;
        }).join('');
    }

    search.addEventListener('input', render);
    filter.addEventListener('change', render);
    render();
}

function populateSignalGrid() {
    const grid = document.getElementById('signal-grid');
    grid.innerHTML = SIGNALS.map(sig => {
        const isRed = sig.state === 'red', isYellow = sig.state === 'yellow',
              isGreen = sig.state === 'green', isBlue = sig.state === 'blue';
        return `
        <div class="signal-card" onclick="showToast('info','Signal ${sig.id}: ${sig.state.toUpperCase()} on ${sig.segment}')">
            <div class="signal-light-stack">
                <div class="sig-bulb ${isRed ? 'active-red' : ''}"></div>
                <div class="sig-bulb ${isYellow ? 'active-yellow' : ''}"></div>
                <div class="sig-bulb ${isGreen ? 'active-green' : ''}"></div>
            </div>
            <span class="signal-label">${sig.id}</span>
        </div>`;
    }).join('');

    // Update stats
    const counts = { green: 0, yellow: 0, red: 0, blue: 0 };
    SIGNALS.forEach(s => counts[s.state]++);
    document.getElementById('sig-total').textContent = SIGNALS.length;
    document.getElementById('sig-clear').textContent = counts.green;
    document.getElementById('sig-caution').textContent = counts.yellow;
    document.getElementById('sig-stop').textContent = counts.red;
    document.getElementById('sig-shunt').textContent = counts.blue;
}

function populateDispatch() {
    const list = document.getElementById('dispatch-list');
    list.innerHTML = DISPATCH_QUEUE.map(d => `
        <div class="dispatch-item">
            <div class="dispatch-priority ${d.priority}"></div>
            <div class="dispatch-info">
                <div class="dispatch-train">${d.train}</div>
                <div class="dispatch-detail">${d.detail}</div>
            </div>
            <span class="dispatch-status ${d.status}">${d.status.charAt(0).toUpperCase() + d.status.slice(1)}</span>
        </div>
    `).join('');
}

function populateDecisionLog() {
    const log = document.getElementById('decision-log');
    log.innerHTML = DECISION_LOG.map(d => `
        <div class="decision-entry">
            <div class="decision-time">${d.time}</div>
            <div class="decision-text">${d.text}</div>
        </div>
    `).join('');
}

function populatePredictions() {
    const container = document.getElementById('prediction-cards');
    container.innerHTML = PREDICTIONS.map(p => `
        <div class="prediction-card">
            <div class="pred-header">
                <span class="pred-type ${p.type}">${p.typeLabel}</span>
                <span class="pred-confidence">${p.confidence}% confidence</span>
            </div>
            <div class="pred-title">${p.title}</div>
            <div class="pred-desc">${p.desc}</div>
            <div class="pred-bar-label">
                <span>Risk Level</span>
                <span>${p.pct}%</span>
            </div>
            <div class="pred-bar">
                <div class="pred-bar-fill ${p.level}" style="width:${p.pct}%"></div>
            </div>
        </div>
    `).join('');
}

function populateRescheduleTimeline() {
    const timeline = document.getElementById('reschedule-timeline');
    timeline.innerHTML = RESCHEDULE_ITEMS.map(r => `
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-train">${r.train}</div>
                <div class="timeline-detail">${r.detail}</div>
                <div class="timeline-time">${r.time}</div>
            </div>
        </div>
    `).join('');
}

function populateSignalControl() {
    const panel = document.getElementById('signalctl-panel');
    panel.innerHTML = '<h3>All Signals</h3>' + SIGNALS.map(sig => {
        const colors = { green: 'var(--accent-green)', yellow: 'var(--accent-yellow)', red: 'var(--accent-red)', blue: 'var(--accent-blue)' };
        return `
        <div class="signal-ctl-row" onclick="inspectSignal('${sig.id}')">
            <div class="sig-indicator" style="background:${colors[sig.state]};box-shadow:0 0 6px ${colors[sig.state]}"></div>
            <span class="sig-name">${sig.id}</span>
            <span class="sig-segment">${sig.segment}</span>
        </div>`;
    }).join('');
}

function inspectSignal(sigId) {
    const sig = SIGNALS.find(s => s.id === sigId);
    if (!sig) return;
    const inspector = document.getElementById('signal-inspector');
    const colors = { green: 'var(--accent-green)', yellow: 'var(--accent-yellow)', red: 'var(--accent-red)', blue: 'var(--accent-blue)' };
    const labels = { green: 'Clear — Proceed', yellow: 'Caution — Reduce Speed', red: 'Stop — Halt', blue: 'Shunting — Yard Movement' };
    inspector.innerHTML = `
        <div style="text-align:center;margin-bottom:16px;">
            <div style="display:inline-flex;flex-direction:column;gap:6px;background:#0d0d0d;padding:10px;border-radius:10px;border:1px solid #222;">
                <div class="sig-bulb ${sig.state === 'red' ? 'active-red' : ''}" style="width:24px;height:24px"></div>
                <div class="sig-bulb ${sig.state === 'yellow' ? 'active-yellow' : ''}" style="width:24px;height:24px"></div>
                <div class="sig-bulb ${sig.state === 'green' ? 'active-green' : ''}" style="width:24px;height:24px"></div>
            </div>
        </div>
        <div class="rs-stat"><span>Signal ID</span><span class="rs-val">${sig.id}</span></div>
        <div class="rs-stat"><span>Segment</span><span class="rs-val">${sig.segment}</span></div>
        <div class="rs-stat"><span>Current State</span><span class="rs-val" style="color:${colors[sig.state]}">${labels[sig.state]}</span></div>
        <div style="margin-top:16px;display:flex;gap:6px;flex-wrap:wrap;">
            <button class="btn-primary" style="flex:1;font-size:0.75rem;padding:8px;" onclick="changeSignal('${sig.id}','green')">Set Clear</button>
            <button class="btn-secondary" style="flex:1;font-size:0.75rem;padding:8px;border-color:var(--accent-yellow);color:var(--accent-yellow);" onclick="changeSignal('${sig.id}','yellow')">Set Caution</button>
            <button class="btn-secondary" style="flex:1;font-size:0.75rem;padding:8px;border-color:var(--accent-red);color:var(--accent-red);" onclick="changeSignal('${sig.id}','red')">Set Stop</button>
        </div>
    `;
}

function changeSignal(sigId, newState) {
    // Call Java API to change signal state
    fetch(`/api/signals/${sigId}/change`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ state: newState })
    }).then(r => r.json()).then(data => {
        if (data.success) {
            showToast('success', data.message);
        }
    }).catch(() => {
        // Fallback: change locally
    });

    const sig = SIGNALS.find(s => s.id === sigId);
    if (sig) {
        sig.state = newState;
        populateSignalGrid();
        populateSignalControl();
        inspectSignal(sigId);
        drawMap();
        showToast('success', `Signal ${sigId} changed to ${newState.toUpperCase()}`);
    }
}

function populateCapacity() {
    const container = document.getElementById('cap-meters');
    container.innerHTML = CAPACITY_SEGMENTS.map(seg => {
        const color = seg.usage > 85 ? 'var(--accent-red)' : seg.usage > 65 ? 'var(--accent-orange)' : 'var(--accent-green)';
        return `
        <div class="cap-meter">
            <div class="cap-meter-label">
                <span>${seg.name}</span>
                <span style="color:${color}">${seg.usage}%</span>
            </div>
            <div class="cap-bar">
                <div class="cap-bar-fill" style="width:${seg.usage}%;background:${color}"></div>
            </div>
        </div>`;
    }).join('');
    setTimeout(() => drawCapacityChart(), 300);
}

function drawCapacityChart() {
    const canvas = document.getElementById('capacity-canvas');
    if (!canvas) return;
    const container = canvas.parentElement;
    const w = container.clientWidth - 40;
    const h = container.clientHeight - 60;
    if (w <= 0 || h <= 0) return;

    canvas.width = w * window.devicePixelRatio;
    canvas.height = h * window.devicePixelRatio;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';

    const c = canvas.getContext('2d');
    c.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
    c.clearRect(0, 0, w, h);

    // Generate 24hr data
    const data = Array.from({ length: 24 }, (_, i) => {
        const base = 30 + Math.sin(i / 24 * Math.PI * 2 - Math.PI / 2) * 35;
        return Math.max(10, Math.min(95, base + (Math.random() - 0.5) * 20));
    });

    const padL = 40, padR = 10, padT = 10, padB = 30;
    const chartW = w - padL - padR;
    const chartH = h - padT - padB;

    // Grid
    c.strokeStyle = 'rgba(30,41,59,0.4)';
    c.lineWidth = 0.5;
    for (let i = 0; i <= 4; i++) {
        const y = padT + (chartH / 4) * i;
        c.beginPath(); c.moveTo(padL, y); c.lineTo(w - padR, y); c.stroke();
        c.font = '10px JetBrains Mono';
        c.fillStyle = '#64748b';
        c.textAlign = 'right';
        c.fillText((100 - i * 25) + '%', padL - 8, y + 4);
    }

    // X axis
    data.forEach((_, i) => {
        if (i % 3 === 0) {
            const x = padL + (chartW / 23) * i;
            c.font = '10px JetBrains Mono';
            c.fillStyle = '#64748b';
            c.textAlign = 'center';
            c.fillText(String(i).padStart(2, '0') + ':00', x, h - 5);
        }
    });

    // Area fill
    const grad = c.createLinearGradient(0, padT, 0, padT + chartH);
    grad.addColorStop(0, 'rgba(108, 92, 231, 0.3)');
    grad.addColorStop(1, 'rgba(108, 92, 231, 0.02)');
    c.beginPath();
    c.moveTo(padL, padT + chartH);
    data.forEach((v, i) => {
        const x = padL + (chartW / 23) * i;
        const y = padT + chartH - (v / 100) * chartH;
        if (i === 0) c.lineTo(x, y);
        else c.lineTo(x, y);
    });
    c.lineTo(padL + chartW, padT + chartH);
    c.closePath();
    c.fillStyle = grad;
    c.fill();

    // Line
    c.beginPath();
    data.forEach((v, i) => {
        const x = padL + (chartW / 23) * i;
        const y = padT + chartH - (v / 100) * chartH;
        if (i === 0) c.moveTo(x, y);
        else c.lineTo(x, y);
    });
    c.strokeStyle = '#6C5CE7';
    c.lineWidth = 2;
    c.stroke();

    // Dots
    data.forEach((v, i) => {
        const x = padL + (chartW / 23) * i;
        const y = padT + chartH - (v / 100) * chartH;
        c.beginPath();
        c.arc(x, y, 3, 0, Math.PI * 2);
        c.fillStyle = v > 80 ? '#FF5252' : v > 60 ? '#FF9100' : '#6C5CE7';
        c.fill();
    });
}

function populateMaintenance() {
    const list = document.getElementById('maint-list');
    const svgIcon = `<svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/></svg>`;
    list.innerHTML = '<h3>Maintenance Items</h3>' + MAINTENANCE_ITEMS.map(m => `
        <div class="maint-item">
            <div class="maint-icon ${m.type}">${svgIcon}</div>
            <div class="maint-info">
                <div class="maint-title">${m.title}</div>
                <div class="maint-desc">${m.desc}</div>
            </div>
            <div class="maint-meta">
                <div class="maint-date">${m.date}</div>
                <span class="maint-status ${m.status}">${m.status.replace('-', ' ').toUpperCase()}</span>
            </div>
        </div>
    `).join('');
}


// ══════════════════ ROUTE OPTIMIZER ══════════════════

function initRouteOptimizer() {
    document.getElementById('btn-optimize').addEventListener('click', runOptimization);
}

function runOptimization() {
    const origin = document.getElementById('route-origin').value;
    const dest = document.getElementById('route-dest').value;
    const priority = document.getElementById('route-priority').value;

    if (origin === dest) {
        showToast('warning', 'Origin and destination cannot be the same.');
        return;
    }

    const originName = document.querySelector(`#route-origin option[value="${origin}"]`).textContent;
    const destName = document.querySelector(`#route-dest option[value="${dest}"]`).textContent;

    showToast('ai', `AI optimizing route: ${originName} → ${destName}...`);

    const container = document.getElementById('route-results');
    container.innerHTML = '<div class="empty-state"><p>AI computing optimal routes...</p></div>';

    // Call Java API (which proxies to Python AI engine)
    fetch('/api/routes/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origin, destination: dest, priority })
    })
    .then(r => r.json())
    .then(data => {
        const routes = data.routes || [];
        renderRouteResults(container, routes, originName, destName);
    })
    .catch(() => {
        // Fallback to local computation
        setTimeout(() => {
            const routes = [
                { name: 'Direct High-Speed', recommended: priority === 'fastest',
                  tag: priority === 'fastest' ? 'AI Recommended' : null,
                  duration: '2h 45m', distance: '485 km', stops: 2, speed: 'Avg 280 km/h',
                  energy: '342 kWh', conflicts: 0, capacity: '78%' },
                { name: 'Via Kolkata (IC)', recommended: priority === 'conflict',
                  tag: priority === 'conflict' ? 'Least Conflicts' : null,
                  duration: '3h 20m', distance: '520 km', stops: 3, speed: 'Avg 210 km/h',
                  energy: '298 kWh', conflicts: 0, capacity: '62%' },
                { name: 'Energy Saver Route', recommended: priority === 'energy',
                  tag: priority === 'energy' ? 'Most Efficient' : null,
                  duration: '4h 10m', distance: '490 km', stops: 5, speed: 'Avg 160 km/h',
                  energy: '215 kWh', conflicts: 1, capacity: '55%' },
            ];
            renderRouteResults(container, routes, originName, destName);
        }, 1500);
    });
}

function renderRouteResults(container, routes, originName, destName) {
    container.innerHTML = routes.map(r => `
        <div class="route-option ${r.recommended ? 'recommended' : ''}">
            <div class="route-option-header">
                <span class="route-name">${r.name}</span>
                ${r.tag ? `<span class="route-tag">${r.tag}</span>` : ''}
            </div>
            <div class="route-meta">
                <div class="route-meta-item">⏱ <strong>${r.duration}</strong></div>
                <div class="route-meta-item">📏 <strong>${r.distance}</strong></div>
                <div class="route-meta-item">🚉 <strong>${r.stops} stops</strong></div>
                <div class="route-meta-item">⚡ <strong>${r.energy}</strong></div>
                <div class="route-meta-item">🚀 <strong>${r.speed}</strong></div>
                <div class="route-meta-item">📊 Cap: <strong>${r.capacity}</strong></div>
            </div>
        </div>
    `).join('');
    showToast('success', `${routes.length} optimal routes computed for ${originName} → ${destName}`);
}


// ══════════════════ LIVE UPDATES ══════════════════

function startLiveUpdates() {
    // Animate trains on map
    setInterval(() => {
        trains.forEach(t => {
            if (t.status !== 'stopped') {
                const speed = (t.speed / 300) * 0.003 * (0.8 + Math.random() * 0.4);
                const from = STATIONS.find(s => s.id === t.fromId);
                const to = STATIONS.find(s => s.id === t.toId);
                if (!from || !to) return;

                t.progress += speed;
                if (t.progress >= 1) {
                    t.progress = 0;
                    // Pick new random route
                    const newRoute = ROUTES[Math.floor(Math.random() * ROUTES.length)];
                    t.fromId = newRoute.from;
                    t.toId = newRoute.to;
                    const fs = STATIONS.find(s => s.id === newRoute.from);
                    const ts = STATIONS.find(s => s.id === newRoute.to);
                    t.route = `${fs.name.split(' ')[0]} → ${ts.name.split(' ')[0]}`;
                }

                const f = STATIONS.find(s => s.id === t.fromId);
                const tgt = STATIONS.find(s => s.id === t.toId);
                t.x = f.x + (tgt.x - f.x) * t.progress;
                t.y = f.y + (tgt.y - f.y) * t.progress;
            }
        });
        drawMap();
    }, 100);

    // Update stats periodically
    setInterval(() => {
        const activeCount = 280 + Math.floor(Math.random() * 10);
        const onTimeRate = (89 + Math.random() * 4).toFixed(1);
        const delayedCount = 20 + Math.floor(Math.random() * 8);
        const aiDecisions = 35 + Math.floor(Math.random() * 12);

        document.getElementById('stat-active').textContent = activeCount;
        document.getElementById('stat-ontime').textContent = onTimeRate + '%';
        document.getElementById('stat-delayed').textContent = delayedCount;
        document.getElementById('stat-ai-decisions').textContent = aiDecisions;

        document.getElementById('count-trains').textContent = trains.filter(t => t.status !== 'stopped').length;
    }, 3000);

    // Random signal changes
    setInterval(() => {
        const idx = Math.floor(Math.random() * SIGNALS.length);
        const states = ['green', 'green', 'green', 'yellow', 'red'];
        SIGNALS[idx].state = states[Math.floor(Math.random() * states.length)];
        // We don't re-render the signal grid constantly to avoid performance issues,
        // but the map will reflect changes
    }, 5000);

    // Random toast notifications from AI
    const aiMessages = [
        'AI rerouted ICE 1523 to avoid Kolkata junction conflict.',
        'Cascade delay prevention activated for Mumbai zone.',
        'Signal SIG-028 auto-cleared after safety verification.',
        'Platform reassignment completed at Hyderabad.',
        'Energy optimization applied to RE 42 route.',
        'Weather advisory updated for northern corridor.',
        'Predictive maintenance alert: track wear detected.',
        'Capacity threshold warning for Chennai.',
    ];

    setInterval(() => {
        const msg = aiMessages[Math.floor(Math.random() * aiMessages.length)];
        showToast('ai', msg);
    }, 15000);
}


// ══════════════════ TOAST NOTIFICATIONS ══════════════════

function showToast(type, message) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    const icons = {
        info: '💡', success: '✅', warning: '⚠️', error: '❌', ai: '🤖'
    };

    toast.innerHTML = `
        <span class="toast-icon">${icons[type] || '💡'}</span>
        <span class="toast-text">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('removing');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ══════════════════ LIVE TRAIN TRACKER ══════════════════

let trackerActive = false;
let trackedTrainId = null;
let trackerAnimFrame = null;
let trackerUpdateInterval = null;

function initTracker() {
    document.getElementById('tracker-back-btn').addEventListener('click', closeTracker);
    // ESC key to close
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && trackerActive) closeTracker();
    });
}

function openTracker(trainId) {
    const train = trains.find(t => t.id === trainId);
    if (!train) return;

    trackedTrainId = trainId;
    trackerActive = true;

    const overlay = document.getElementById('tracker-overlay');
    overlay.classList.add('active');

    // Populate header
    document.getElementById('tracker-title').textContent = train.name;
    document.getElementById('tracker-route-label').textContent = train.route;

    const badge = document.getElementById('tracker-badge');
    badge.textContent = train.name;
    badge.className = 'tracker-train-badge' + (train.type === 'ic' ? ' type-ic' : train.type === 're' ? ' type-re' : '');

    updateTrackerStatus(train);
    updateTrackerInfo(train);
    updateTrackerStats(train);
    buildRouteTimeline(train);
    updateDelayCard(train);

    // Start live updates
    setTimeout(() => {
        resizeTrackerCanvas();
        drawTrackerMap(train);
    }, 100);

    trackerUpdateInterval = setInterval(() => {
        const t = trains.find(tr => tr.id === trackedTrainId);
        if (!t) return;
        updateTrackerStatus(t);
        updateTrackerStats(t);
        buildRouteTimeline(t);
        drawTrackerMap(t);
        drawSpeedGauge(t.speed, t.type === 'ice' ? 300 : t.type === 'ic' ? 200 : 120);
        document.getElementById('speed-number').textContent = t.speed;
        document.getElementById('tracker-map-update').textContent = 'Updated ' + new Date().toLocaleTimeString('en-GB');
    }, 500);

    // Initial speed gauge
    drawSpeedGauge(train.speed, train.type === 'ice' ? 300 : train.type === 'ic' ? 200 : 120);
    document.getElementById('speed-number').textContent = train.speed;

    showToast('ai', `Now tracking ${train.name} in real-time`);
}

function closeTracker() {
    trackerActive = false;
    trackedTrainId = null;
    document.getElementById('tracker-overlay').classList.remove('active');
    if (trackerUpdateInterval) {
        clearInterval(trackerUpdateInterval);
        trackerUpdateInterval = null;
    }
    if (trackerAnimFrame) {
        cancelAnimationFrame(trackerAnimFrame);
        trackerAnimFrame = null;
    }
}

function updateTrackerStatus(train) {
    const pill = document.getElementById('tracker-status');
    if (train.status === 'on-time') {
        pill.textContent = '● On Time';
        pill.className = 'tracker-status-pill';
    } else if (train.status === 'delayed') {
        pill.textContent = `● Delayed +${train.delay}m`;
        pill.className = 'tracker-status-pill delayed';
    } else {
        pill.textContent = '● Stopped';
        pill.className = 'tracker-status-pill stopped';
    }
}

function updateTrackerInfo(train) {
    const grid = document.getElementById('tracker-info-grid');
    const fromSt = STATIONS.find(s => s.id === train.fromId);
    const toSt = STATIONS.find(s => s.id === train.toId);
    const route = ROUTES.find(r => (r.from === train.fromId && r.to === train.toId) || (r.from === train.toId && r.to === train.fromId));
    const typeLabels = { ice: 'High-Speed (ICE)', ic: 'Intercity (IC)', re: 'Regional (RE)' };
    grid.innerHTML = `
        <div class="info-item">
            <div class="info-item-label">Train ID</div>
            <div class="info-item-value">${train.id}</div>
        </div>
        <div class="info-item">
            <div class="info-item-label">Type</div>
            <div class="info-item-value">${typeLabels[train.type] || train.type}</div>
        </div>
        <div class="info-item">
            <div class="info-item-label">Origin</div>
            <div class="info-item-value">${fromSt ? fromSt.name : '--'}</div>
        </div>
        <div class="info-item">
            <div class="info-item-label">Destination</div>
            <div class="info-item-value">${toSt ? toSt.name : '--'}</div>
        </div>
        <div class="info-item">
            <div class="info-item-label">Distance</div>
            <div class="info-item-value">${route ? route.distance + ' km' : '--'}</div>
        </div>
        <div class="info-item">
            <div class="info-item-label">Departure</div>
            <div class="info-item-value">${train.departTime}</div>
        </div>
    `;

    const maxSpeeds = { ice: '300 km/h', ic: '200 km/h', re: '120 km/h' };
    document.getElementById('tracker-max-speed').textContent = maxSpeeds[train.type] || '200 km/h';
    document.getElementById('tracker-avg-speed').textContent = Math.round(train.speed * 0.85) + ' km/h';
}

function updateTrackerStats(train) {
    const route = ROUTES.find(r => (r.from === train.fromId && r.to === train.toId) || (r.from === train.toId && r.to === train.fromId));
    const dist = route ? route.distance : 300;
    const progressPct = Math.round(train.progress * 100);
    const distLeft = Math.round(dist * (1 - train.progress));
    const etaMin = train.speed > 0 ? Math.round((distLeft / train.speed) * 60) : '--';

    document.getElementById('tls-progress').textContent = progressPct + '%';
    document.getElementById('tls-eta').textContent = etaMin + ' min';
    document.getElementById('tls-distance').textContent = distLeft + ' km';

    const aiStatuses = ['Monitoring', 'Optimizing', 'Active', 'Analyzing'];
    const aiIdx = Math.floor(Date.now() / 5000) % aiStatuses.length;
    document.getElementById('tls-ai').textContent = aiStatuses[aiIdx];
}

function updateDelayCard(train) {
    const card = document.getElementById('tracker-delay-card');
    if (train.status === 'delayed') {
        card.style.display = 'block';
        const reasons = [
            'Upstream signal hold causing chain delay',
            'Platform congestion at previous station',
            'Speed restriction due to weather conditions',
            'Waiting for connecting train transfer',
        ];
        const reason = reasons[Math.floor(Math.random() * reasons.length)];
        document.getElementById('delay-info').innerHTML = `
            <div class="delay-reason">+${train.delay} minutes delayed</div>
            <div>Reason: ${reason}</div>
            <div class="delay-ai-action">🤖 AI Action: Adjusting departure windows for connecting trains. Estimated recovery in ${Math.max(3, train.delay - 5)} minutes.</div>
        `;
    } else if (train.status === 'stopped') {
        card.style.display = 'block';
        document.getElementById('delay-info').innerHTML = `
            <div class="delay-reason">Train currently stopped</div>
            <div>Awaiting signal clearance or scheduled stop.</div>
            <div class="delay-ai-action">🤖 AI Action: Monitoring signal status. Will auto-dispatch when route is clear.</div>
        `;
    } else {
        card.style.display = 'none';
    }
}

function buildRouteTimeline(train) {
    const timeline = document.getElementById('tracker-route-timeline');
    const fromSt = STATIONS.find(s => s.id === train.fromId);
    const toSt = STATIONS.find(s => s.id === train.toId);
    if (!fromSt || !toSt) return;

    // Build intermediate stops
    const stops = [fromSt];
    // Find one or two intermediate stations based on route connections
    const midStations = STATIONS.filter(s => s.id !== train.fromId && s.id !== train.toId);
    // Pick 1-2 intermediates based on proximity
    const midCandidates = midStations
        .map(s => ({
            ...s,
            dist: Math.abs(s.x - (fromSt.x + toSt.x)/2) + Math.abs(s.y - (fromSt.y + toSt.y)/2)
        }))
        .sort((a, b) => a.dist - b.dist)
        .slice(0, 2);
    
    // Sort intermediates by progress along the route
    midCandidates.sort((a, b) => {
        const progA = ((a.x - fromSt.x) / (toSt.x - fromSt.x + 0.001) + (a.y - fromSt.y) / (toSt.y - fromSt.y + 0.001)) / 2;
        const progB = ((b.x - fromSt.x) / (toSt.x - fromSt.x + 0.001) + (b.y - fromSt.y) / (toSt.y - fromSt.y + 0.001)) / 2;
        return progA - progB;
    });
    
    stops.push(...midCandidates);
    stops.push(toSt);

    const totalStops = stops.length;
    const now = new Date();

    let html = '';
    stops.forEach((stop, i) => {
        const stopProgress = i / (totalStops - 1);
        let cls = '';
        if (train.progress >= stopProgress + 0.05) cls = 'passed';
        else if (train.progress >= stopProgress - 0.15 && train.progress < stopProgress + 0.05) cls = 'current';

        const timeOffset = Math.round(i * 25 + Math.random() * 10);
        const arrTime = new Date(now.getTime() - (totalStops - 1 - i) * 15 * 60000);
        const timeStr = arrTime.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

        html += `<div class="route-stop ${cls}">
            <div class="route-stop-dot"></div>
            <div class="route-stop-name">${stop.name.replace(' Hbf', '')}</div>
            <div class="route-stop-time">${timeStr}</div>
        </div>`;

        if (i < totalStops - 1) {
            const nextProgress = (i + 1) / (totalStops - 1);
            let connCls = '';
            if (train.progress >= nextProgress) connCls = 'filled';
            else if (train.progress > stopProgress) connCls = 'active';
            html += `<div class="route-connector ${connCls}"></div>`;
        }
    });

    timeline.innerHTML = html;
}

// ——— Tracker Route Map (Canvas) ———
function resizeTrackerCanvas() {
    const wrap = document.querySelector('.tracker-map-canvas-wrap');
    const cvs = document.getElementById('tracker-map-canvas');
    if (!wrap || !cvs) return;
    const w = wrap.clientWidth;
    const h = wrap.clientHeight;
    cvs.width = w * window.devicePixelRatio;
    cvs.height = h * window.devicePixelRatio;
    cvs.style.width = w + 'px';
    cvs.style.height = h + 'px';
}

function drawTrackerMap(train) {
    const cvs = document.getElementById('tracker-map-canvas');
    if (!cvs) return;
    const w = cvs.clientWidth;
    const h = cvs.clientHeight;
    if (w <= 0 || h <= 0) return;

    // Ensure size is correct
    if (cvs.width !== w * window.devicePixelRatio) resizeTrackerCanvas();

    const c = cvs.getContext('2d');
    c.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
    c.clearRect(0, 0, w, h);

    const fromSt = STATIONS.find(s => s.id === train.fromId);
    const toSt = STATIONS.find(s => s.id === train.toId);
    if (!fromSt || !toSt) return;

    // Calculate bounding box to center the route
    const padding = 80;
    const allX = STATIONS.map(s => s.x);
    const allY = STATIONS.map(s => s.y);
    const minX = Math.min(...allX), maxX = Math.max(...allX);
    const minY = Math.min(...allY), maxY = Math.max(...allY);
    const scaleX = (w - padding * 2) / (maxX - minX || 1);
    const scaleY = (h - padding * 2) / (maxY - minY || 1);
    const scale = Math.min(scaleX, scaleY);
    const offX = (w - (maxX - minX) * scale) / 2 - minX * scale;
    const offY = (h - (maxY - minY) * scale) / 2 - minY * scale;

    function tx(x) { return x * scale + offX; }
    function ty(y) { return y * scale + offY; }

    // Grid
    c.strokeStyle = 'rgba(30,41,59,0.15)';
    c.lineWidth = 0.5;
    for (let x = 0; x < w; x += 50) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, h); c.stroke(); }
    for (let y = 0; y < h; y += 50) { c.beginPath(); c.moveTo(0, y); c.lineTo(w, y); c.stroke(); }

    // Draw all routes (dimmed)
    ROUTES.forEach(route => {
        const f = STATIONS.find(s => s.id === route.from);
        const t = STATIONS.find(s => s.id === route.to);
        if (!f || !t) return;
        c.beginPath();
        c.moveTo(tx(f.x), ty(f.y));
        const mx = (tx(f.x) + tx(t.x)) / 2 + (ty(t.y) - ty(f.y)) * 0.12;
        const my = (ty(f.y) + ty(t.y)) / 2 - (tx(t.x) - tx(f.x)) * 0.12;
        c.quadraticCurveTo(mx, my, tx(t.x), ty(t.y));
        c.strokeStyle = 'rgba(30,41,59,0.25)';
        c.lineWidth = 1;
        c.stroke();
    });

    // Highlight the train's route
    const fx1 = tx(fromSt.x), fy1 = ty(fromSt.y);
    const fx2 = tx(toSt.x), fy2 = ty(toSt.y);
    const hmx = (fx1 + fx2) / 2 + (fy2 - fy1) * 0.12;
    const hmy = (fy1 + fy2) / 2 - (fx2 - fx1) * 0.12;

    // Route glow
    c.beginPath();
    c.moveTo(fx1, fy1);
    c.quadraticCurveTo(hmx, hmy, fx2, fy2);
    c.strokeStyle = train.type === 'ice' ? 'rgba(108,92,231,0.4)' : train.type === 'ic' ? 'rgba(0,207,253,0.4)' : 'rgba(0,230,118,0.4)';
    c.lineWidth = 6;
    c.stroke();

    // Route line
    c.beginPath();
    c.moveTo(fx1, fy1);
    c.quadraticCurveTo(hmx, hmy, fx2, fy2);
    c.strokeStyle = train.type === 'ice' ? '#6C5CE7' : train.type === 'ic' ? '#00CFFD' : '#00E676';
    c.lineWidth = 3;
    c.stroke();

    // Draw all stations (small)
    STATIONS.forEach(st => {
        if (st.id === train.fromId || st.id === train.toId) return;
        c.beginPath();
        c.arc(tx(st.x), ty(st.y), 3, 0, Math.PI * 2);
        c.fillStyle = 'rgba(100,116,139,0.5)';
        c.fill();
        c.font = '500 8px Inter';
        c.fillStyle = 'rgba(148,163,184,0.5)';
        c.textAlign = 'center';
        c.fillText(st.name.replace(' Hbf', ''), tx(st.x), ty(st.y) - 8);
    });

    // Draw origin station
    c.beginPath();
    c.arc(fx1, fy1, 8, 0, Math.PI * 2);
    c.fillStyle = 'rgba(0,230,118,0.15)';
    c.fill();
    c.beginPath();
    c.arc(fx1, fy1, 5, 0, Math.PI * 2);
    c.fillStyle = '#00E676';
    c.fill();
    c.font = '600 11px Inter';
    c.fillStyle = '#00E676';
    c.textAlign = 'center';
    c.fillText(fromSt.name, fx1, fy1 - 14);

    // Draw destination station
    c.beginPath();
    c.arc(fx2, fy2, 8, 0, Math.PI * 2);
    c.fillStyle = 'rgba(255,82,82,0.15)';
    c.fill();
    c.beginPath();
    c.arc(fx2, fy2, 5, 0, Math.PI * 2);
    c.fillStyle = '#FF5252';
    c.fill();
    c.font = '600 11px Inter';
    c.fillStyle = '#FF5252';
    c.textAlign = 'center';
    c.fillText(toSt.name, fx2, fy2 - 14);

    // Draw train position
    const trainX = tx(train.x);
    const trainY = ty(train.y);
    const trainColor = train.status === 'on-time' ? '#6C5CE7' : train.status === 'delayed' ? '#FF9100' : '#FF5252';

    // Animated pulse ring
    const pulseSize = 12 + Math.sin(Date.now() / 300) * 4;
    c.beginPath();
    c.arc(trainX, trainY, pulseSize, 0, Math.PI * 2);
    c.fillStyle = trainColor.replace(')', ',0.15)').replace('#', 'rgba(').replace(/([0-9A-F]{2})([0-9A-F]{2})([0-9A-F]{2})/i, (m, r, g, b) => `${parseInt(r,16)},${parseInt(g,16)},${parseInt(b,16)}`);
    const pg = c.createRadialGradient(trainX, trainY, 0, trainX, trainY, pulseSize);
    pg.addColorStop(0, trainColor + '40');
    pg.addColorStop(1, trainColor + '00');
    c.fillStyle = pg;
    c.fill();

    // Train dot
    c.beginPath();
    c.arc(trainX, trainY, 7, 0, Math.PI * 2);
    c.fillStyle = trainColor;
    c.fill();
    c.strokeStyle = '#fff';
    c.lineWidth = 2;
    c.stroke();

    // Train label
    c.font = '700 11px JetBrains Mono';
    c.fillStyle = '#fff';
    c.textAlign = 'left';
    const labelBg = c.measureText(train.name);
    c.fillStyle = 'rgba(10,14,23,0.85)';
    c.beginPath();
    c.roundRect(trainX + 12, trainY - 10, labelBg.width + 12, 20, 4);
    c.fill();
    c.fillStyle = trainColor;
    c.fillText(train.name, trainX + 18, trainY + 4);

    // Speed label
    c.font = '500 9px JetBrains Mono';
    c.fillStyle = 'rgba(148,163,184,0.8)';
    c.fillText(train.speed + ' km/h', trainX + 18, trainY + 18);
}

// ——— Speed Gauge ———
function drawSpeedGauge(speed, maxSpeed) {
    const cvs = document.getElementById('speed-gauge-canvas');
    if (!cvs) return;
    const c = cvs.getContext('2d');
    const w = cvs.width, h = cvs.height;
    c.clearRect(0, 0, w, h);

    const cx = w / 2, cy = h - 10;
    const radius = Math.min(w, h) - 30;
    const startAngle = Math.PI;
    const endAngle = 2 * Math.PI;
    const speedAngle = startAngle + (speed / maxSpeed) * Math.PI;

    // Background arc
    c.beginPath();
    c.arc(cx, cy, radius, startAngle, endAngle);
    c.strokeStyle = '#1e293b';
    c.lineWidth = 12;
    c.lineCap = 'round';
    c.stroke();

    // Speed arc
    if (speed > 0) {
        const grad = c.createLinearGradient(cx - radius, cy, cx + radius, cy);
        grad.addColorStop(0, '#6C5CE7');
        grad.addColorStop(0.5, '#00CFFD');
        grad.addColorStop(1, speed > maxSpeed * 0.8 ? '#FF5252' : '#00E676');
        c.beginPath();
        c.arc(cx, cy, radius, startAngle, speedAngle);
        c.strokeStyle = grad;
        c.lineWidth = 12;
        c.lineCap = 'round';
        c.stroke();

        // Glow
        c.beginPath();
        c.arc(cx, cy, radius, startAngle, speedAngle);
        c.strokeStyle = grad;
        c.lineWidth = 20;
        c.globalAlpha = 0.15;
        c.stroke();
        c.globalAlpha = 1;
    }

    // Tick marks
    for (let i = 0; i <= 6; i++) {
        const angle = startAngle + (i / 6) * Math.PI;
        const x1 = cx + Math.cos(angle) * (radius - 18);
        const y1 = cy + Math.sin(angle) * (radius - 18);
        const x2 = cx + Math.cos(angle) * (radius - 8);
        const y2 = cy + Math.sin(angle) * (radius - 8);
        c.beginPath();
        c.moveTo(x1, y1);
        c.lineTo(x2, y2);
        c.strokeStyle = '#64748b';
        c.lineWidth = 1.5;
        c.stroke();

        // Labels
        const lx = cx + Math.cos(angle) * (radius - 28);
        const ly = cy + Math.sin(angle) * (radius - 28);
        c.font = '500 9px JetBrains Mono';
        c.fillStyle = '#64748b';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText(Math.round(maxSpeed * i / 6), lx, ly);
    }

    // Needle dot
    const nx = cx + Math.cos(speedAngle) * radius;
    const ny = cy + Math.sin(speedAngle) * radius;
    c.beginPath();
    c.arc(nx, ny, 5, 0, Math.PI * 2);
    c.fillStyle = '#fff';
    c.fill();
    c.beginPath();
    c.arc(nx, ny, 3, 0, Math.PI * 2);
    c.fillStyle = '#6C5CE7';
    c.fill();
}
