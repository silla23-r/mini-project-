package com.attcs.service;

import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * ═══════════════════════════════════════════════════
 * ATTCS AI — Dispatch Decision Engine (Pure Java)
 * Mirrors: ai-engine/ai_dispatcher.py
 * ═══════════════════════════════════════════════════
 */
@Service
public class AiDispatcherService {

    private static final List<Map<String, String>> TRAINS = List.of(
        train("ICE 1523","Kolkata","Hyderabad","high"),
        train("IC 932",  "Bengaluru",    "Ahmedabad","medium"),
        train("RE 3",    "Nagpur",  "Surat","low"),
        train("ICE 374", "New Delhi",  "Chennai",  "high"),
        train("IC 117",  "Pune", "Jaipur", "medium"),
        train("RE 42",   "Lucknow", "Pune",  "low"),
        train("ICE 691", "Mumbai", "New Delhi",   "high")
    );

    private static final String[] ACTIONS = {
        "Cleared for immediate departure",
        "Platform assignment confirmed",
        "Awaiting signal clearance",
        "Rerouted via alternate corridor",
        "Departure window adjusted +%d min",
        "Express priority override applied",
        "Cascade delay prevention active"
    };

    public List<Map<String, Object>> getDecisions() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        java.time.LocalTime now = java.time.LocalTime.now();
        List<Map<String, Object>> decisions = new ArrayList<>();

        for (Map<String, String> t : TRAINS) {
            String priority = t.get("priority");
            int offset = rnd.nextInt(-5, 16);
            String dep = now.plusMinutes(offset).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));

            Map<String, Object> d = new LinkedHashMap<>();
            d.put("trainId",            t.get("id"));
            d.put("origin",             t.get("origin"));
            d.put("destination",        t.get("dest"));
            d.put("priority",           priority);
            d.put("status",             status(priority, rnd));
            d.put("action",             action(rnd));
            d.put("confidence",         rnd.nextInt(72, 99));
            d.put("scheduledDeparture", dep);
            d.put("aiEngine",           "java");
            decisions.add(d);
        }
        Map<String, Integer> order = Map.of("high", 0, "medium", 1, "low", 2);
        decisions.sort(Comparator.comparingInt(d -> order.getOrDefault((String) d.get("priority"), 9)));
        return decisions;
    }

    public List<Map<String, String>> getDecisionLog() {
        java.time.LocalTime now = java.time.LocalTime.now();
        java.time.format.DateTimeFormatter fmt = java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss");
        return List.of(
            log(now.minusMinutes(1).format(fmt), "Reduced speed limit on <span class=\"highlight\">BOM-CCU</span> to 160 km/h due to crosswind advisory."),
            log(now.minusMinutes(2).format(fmt), "Rerouted <span class=\"highlight\">ICE 847</span> via Pune to avoid signaling issue at New Delhi south junction."),
            log(now.minusMinutes(3).format(fmt), "Swapped platform for <span class=\"highlight\">IC 204</span> at Bengaluru — Platform 3 → Platform 7."),
            log(now.minusMinutes(4).format(fmt), "Extended dwell time for <span class=\"highlight\">RE 19</span> at Hyderabad by 4 minutes."),
            log(now.minusMinutes(5).format(fmt), "Initiated cascade delay prevention: adjusted departure windows for 3 trains in <span class=\"highlight\">Mumbai zone</span>."),
            log(now.minusMinutes(7).format(fmt), "Cleared signal <span class=\"highlight\">SIG-028</span> after automated safety check passed."),
            log(now.minusMinutes(9).format(fmt), "AI confidence for <span class=\"highlight\">ICE 1523</span> delay prediction increased to 87%. Proactive reroute prepared."),
            log(now.minusMinutes(11).format(fmt), "Assigned <span class=\"highlight\">ICE 85</span> to high-speed segment MAA-JAI for on-time performance.")
        );
    }

    private String status(String priority, ThreadLocalRandom rnd) {
        return switch (priority) {
            case "high"   -> rnd.nextBoolean() ? "dispatched" : "processing";
            case "medium" -> rnd.nextBoolean() ? "processing" : "queued";
            default       -> rnd.nextBoolean() ? "queued"     : "dispatched";
        };
    }

    private String action(ThreadLocalRandom rnd) {
        String a = ACTIONS[rnd.nextInt(ACTIONS.length)];
        return a.contains("%d") ? String.format(a, rnd.nextInt(2, 9)) : a;
    }

    private Map<String, String> log(String time, String text) {
        return Map.of("time", time, "text", text);
    }

    private static Map<String, String> train(String id, String origin, String dest, String priority) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("id", id); m.put("origin", origin); m.put("dest", dest); m.put("priority", priority);
        return m;
    }
}
