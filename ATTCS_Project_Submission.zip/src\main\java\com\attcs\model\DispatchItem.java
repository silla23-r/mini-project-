package com.attcs.model;

/**
 * Item in the AI dispatch queue.
 */
public class DispatchItem {
    private String train;
    private String detail;
    private String priority;  // "high", "medium", "low"
    private String status;    // "processing", "queued", "dispatched"

    public DispatchItem() {}

    public DispatchItem(String train, String detail, String priority, String status) {
        this.train = train;
        this.detail = detail;
        this.priority = priority;
        this.status = status;
    }

    // ── Getters & Setters ──
    public String getTrain() { return train; }
    public void setTrain(String train) { this.train = train; }
    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
