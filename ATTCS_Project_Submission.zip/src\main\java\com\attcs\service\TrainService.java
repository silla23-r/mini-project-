package com.attcs.service;

import com.attcs.model.Route;
import com.attcs.model.Station;
import com.attcs.model.Train;
import com.attcs.repository.TrainRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Manages all active trains — generation, live position updates, and status.
 * Mirrors the JS generateTrains() + startLiveUpdates() logic.
 */
@Service
public class TrainService {

    private final NetworkService networkService;
    private final TrainRepository trainRepository;
    private final Random random = new Random();

    private static final String[] TRAIN_NAMES = {
        "ICE 847", "IC 204", "ICE 72", "IC 501", "RE 19", "ICE 85",
        "ICE 1523", "IC 932", "RE 3", "ICE 374", "IC 117", "RE 42",
        "ICE 691", "IC 813", "RE 7", "ICE 208", "IC 445", "RE 55",
        "ICE 1090", "IC 622", "RE 81", "ICE 519", "IC 306", "RE 14",
    };

    private static final String[] STATUSES = {
        "on-time", "on-time", "on-time", "on-time", "delayed", "delayed", "stopped"
    };

    // ── Live stats ──
    private int activeCount = 284;
    private double onTimeRate = 90.3;
    private int delayedCount = 23;
    private int aiDecisions = 39;

    public TrainService(NetworkService networkService, TrainRepository trainRepository) {
        this.networkService = networkService;
        this.trainRepository = trainRepository;
    }

    @PostConstruct
    public void init() {
        generateTrains();
    }

    /**
     * Generate initial train set — mirrors JS generateTrains().
     */
    private void generateTrains() {
        List<Route> routes = networkService.getRoutes();

        for (int i = 0; i < TRAIN_NAMES.length; i++) {
            String name = TRAIN_NAMES[i];
            String type = name.startsWith("ICE") ? "ice" : name.startsWith("IC ") ? "ic" : "re";
            Route route = routes.get(i % routes.size());
            double progress = random.nextDouble();
            String status = STATUSES[random.nextInt(STATUSES.length)];

            int speed;
            if ("stopped".equals(status)) {
                speed = 0;
            } else if ("ice".equals(type)) {
                speed = 180 + random.nextInt(120);
            } else if ("ic".equals(type)) {
                speed = 120 + random.nextInt(80);
            } else {
                speed = 60 + random.nextInt(60);
            }

            int delay = "delayed".equals(status) ? random.nextInt(25) + 3 : 0;

            Station fromSt = networkService.findStation(route.getFrom());
            Station toSt = networkService.findStation(route.getTo());

            Train train = new Train();
            // id auto-generated
            train.setName(name);
            train.setType(type);
            train.setRoute(fromSt.getName().split(" ")[0] + " → " + toSt.getName().split(" ")[0]);
            train.setFromId(route.getFrom());
            train.setToId(route.getTo());
            train.setProgress(progress);
            train.setStatus(status);
            train.setSpeed(speed);
            train.setDelay(delay);
            train.setX(fromSt.getX() + (toSt.getX() - fromSt.getX()) * progress);
            train.setY(fromSt.getY() + (toSt.getY() - fromSt.getY()) * progress);
            train.setNextStation(progress > 0.5 ? toSt.getName() : fromSt.getName());
            train.setEta((random.nextInt(50) + 5) + " min");
            train.setDepartTime(
                String.format("%02d:%02d", random.nextInt(24), random.nextInt(60))
            );

            trainRepository.save(train);
        }
    }

    /**
     * Live update — moves trains along their routes.
     * Runs every 100ms, same as JS setInterval 100ms.
     */
    @Scheduled(fixedRate = 100)
    public void updateTrainPositions() {
        List<Route> routes = networkService.getRoutes();
        List<Train> trains = trainRepository.findAll();

        for (Train t : trains) {
            if (!"stopped".equals(t.getStatus())) {
                double speed = (t.getSpeed() / 300.0) * 0.003 * (0.8 + random.nextDouble() * 0.4);
                Station from = networkService.findStation(t.getFromId());
                Station to = networkService.findStation(t.getToId());
                if (from == null || to == null) continue;

                double progress = t.getProgress() + speed;
                if (progress >= 1.0) {
                    progress = 0;
                    Route newRoute = routes.get(random.nextInt(routes.size()));
                    t.setFromId(newRoute.getFrom());
                    t.setToId(newRoute.getTo());
                    Station fs = networkService.findStation(newRoute.getFrom());
                    Station ts = networkService.findStation(newRoute.getTo());
                    t.setRoute(fs.getName().split(" ")[0] + " → " + ts.getName().split(" ")[0]);
                    from = fs;
                    to = ts;
                }
                t.setProgress(progress);
                t.setX(from.getX() + (to.getX() - from.getX()) * progress);
                t.setY(from.getY() + (to.getY() - from.getY()) * progress);
                trainRepository.save(t);
            }
        }
    }

    /**
     * Periodically update dashboard stats — mirrors JS setInterval 3000ms.
     */
    @Scheduled(fixedRate = 3000)
    public void updateStats() {
        activeCount = 280 + random.nextInt(10);
        onTimeRate = Math.round((89 + random.nextDouble() * 4) * 10.0) / 10.0;
        delayedCount = 20 + random.nextInt(8);
        aiDecisions = 35 + random.nextInt(12);
    }

    // ── Public accessors ──

    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    public Train findTrain(String id) {
        return trainRepository.findById(Long.parseLong(id)).orElse(null);
    }

    public int getActiveCount() { return activeCount; }
    public double getOnTimeRate() { return onTimeRate; }
    public int getDelayedCount() { return delayedCount; }
    public int getAiDecisions() { return aiDecisions; }

    public long getRunningCount() {
        return trainRepository.findAll().stream().filter(t -> !"stopped".equals(t.getStatus())).count();
    }
}
