package com.attcs.model;

/**
 * Station on the rail network.
 */
public class Station {
    private String id;
    private String name;
    private double x;  // Normalized map coordinate (0..1)
    private double y;

    public Station() {}

    public Station(String id, String name, double x, double y) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
    }

    // ── Getters & Setters ──
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getX() { return x; }
    public void setX(double x) { this.x = x; }
    public double getY() { return y; }
    public void setY(double y) { this.y = y; }
}
