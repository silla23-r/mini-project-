package com.attcs.service;

import org.springframework.stereotype.Service;

import java.util.*;

/**
 * AI Service Router — delegates all AI work to native Java AI services.
 * Python HTTP calls have been completely removed.
 * The application now runs as a single self-contained Java process.
 */
@Service
public class AiProxyService {

    private final AiOptimizerService  optimizer;
    private final AiPredictorService  predictor;
    private final AiDispatcherService dispatcher;
    private final AiReschedulerService rescheduler;

    public AiProxyService(AiOptimizerService optimizer,
                          AiPredictorService predictor,
                          AiDispatcherService dispatcher,
                          AiReschedulerService rescheduler) {
        this.optimizer   = optimizer;
        this.predictor   = predictor;
        this.dispatcher  = dispatcher;
        this.rescheduler = rescheduler;
    }

    /**
     * Optimize a route using the native Java BFS optimizer.
     */
    public List<Map<String, Object>> optimizeRoute(String origin, String destination, String priority) {
        return optimizer.optimize(origin, destination, priority);
    }

    /**
     * Get AI predictions from the native Java predictor.
     * Returns null to signal callers to use their own defaults if needed.
     * (PredictionController now calls AiPredictorService directly.)
     */
    public List<Map<String, Object>> getPredictions() {
        // Kept for interface compatibility; PredictionController uses AiPredictorService directly
        return null;
    }

    /**
     * Get dispatch decisions from the native Java dispatcher.
     */
    public List<Map<String, Object>> getDispatchDecisions() {
        return dispatcher.getDecisions();
    }

    /**
     * Get rescheduling data from the native Java rescheduler.
     */
    public Map<String, Object> getRescheduling() {
        return rescheduler.generateSchedule();
    }
}
