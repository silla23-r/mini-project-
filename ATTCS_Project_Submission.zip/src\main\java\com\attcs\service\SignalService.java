package com.attcs.service;

import com.attcs.model.Route;
import com.attcs.model.Signal;
import com.attcs.repository.SignalRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Manages railway signals — generation, state changes, statistics.
 */
@Service
public class SignalService {

    private final NetworkService networkService;
    private final SignalRepository signalRepository;
    private final Random random = new Random();

    private static final String[] INITIAL_STATES = {
        "green", "green", "green", "green", "green", "green", "yellow", "yellow", "red", "blue"
    };

    public SignalService(NetworkService networkService, SignalRepository signalRepository) {
        this.networkService = networkService;
        this.signalRepository = signalRepository;
    }

    @PostConstruct
    public void init() {
        List<Route> routes = networkService.getRoutes();
        for (int i = 0; i < 48; i++) {
            Route route = routes.get(i % routes.size());
            String segment = route.getFrom().substring(0, 3).toUpperCase()
                    + "-" + route.getTo().substring(0, 3).toUpperCase();
            String state = INITIAL_STATES[random.nextInt(INITIAL_STATES.length)];
            signalRepository.save(new Signal(
                String.format("SIG-%03d", i + 1),
                segment,
                state
            ));
        }
    }

    /**
     * Random signal state changes — mirrors JS setInterval 5000ms.
     */
    @Scheduled(fixedRate = 5000)
    public void randomSignalChange() {
        List<Signal> signals = signalRepository.findAll();
        if (signals.isEmpty()) return;
        int idx = random.nextInt(signals.size());
        String[] states = {"green", "green", "green", "yellow", "red"};
        signals.get(idx).setState(states[random.nextInt(states.length)]);
        signalRepository.save(signals.get(idx));
    }

    public List<Signal> getAllSignals() {
        return signalRepository.findAll();
    }

    public Signal findSignal(String id) {
        return signalRepository.findById(id).orElse(null);
    }

    public boolean changeSignalState(String id, String newState) {
        Signal sig = signalRepository.findById(id).orElse(null);
        if (sig != null) {
            sig.setState(newState);
            signalRepository.save(sig);
            return true;
        }
        return false;
    }

    /**
     * Returns signal count statistics.
     */
    public Map<String, Object> getStats() {
        List<Signal> signals = signalRepository.findAll();
        Map<String, Integer> counts = new HashMap<>();
        counts.put("green", 0);
        counts.put("yellow", 0);
        counts.put("red", 0);
        counts.put("blue", 0);
        for (Signal s : signals) {
            counts.merge(s.getState(), 1, Integer::sum);
        }

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total", signals.size());
        stats.put("clear", counts.getOrDefault("green", 0));
        stats.put("caution", counts.getOrDefault("yellow", 0));
        stats.put("stop", counts.getOrDefault("red", 0));
        stats.put("shunt", counts.getOrDefault("blue", 0));
        return stats;
    }
}
