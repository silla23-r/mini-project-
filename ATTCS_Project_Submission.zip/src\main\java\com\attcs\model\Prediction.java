package com.attcs.model;

/**
 * AI prediction entry.
 */
public class Prediction {
    private String type;        // "delay", "congestion", "weather", "maintenance"
    private String typeLabel;
    private int confidence;
    private String title;
    private String desc;
    private String level;       // "high", "medium", "low"
    private int pct;

    public Prediction() {}

    public Prediction(String type, String typeLabel, int confidence, String title, String desc, String level, int pct) {
        this.type = type;
        this.typeLabel = typeLabel;
        this.confidence = confidence;
        this.title = title;
        this.desc = desc;
        this.level = level;
        this.pct = pct;
    }

    // ── Getters & Setters ──
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getTypeLabel() { return typeLabel; }
    public void setTypeLabel(String typeLabel) { this.typeLabel = typeLabel; }
    public int getConfidence() { return confidence; }
    public void setConfidence(int confidence) { this.confidence = confidence; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDesc() { return desc; }
    public void setDesc(String desc) { this.desc = desc; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public int getPct() { return pct; }
    public void setPct(int pct) { this.pct = pct; }
}
