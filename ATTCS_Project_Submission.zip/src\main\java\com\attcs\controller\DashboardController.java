package com.attcs.controller;

import com.attcs.model.*;
import com.attcs.service.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * REST API for dashboard data — stats, alerts, board trains, AI actions.
 * All AI data now served by native Java AI engine.
 */
@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final TrainService trainService;
    private final NetworkService networkService;
    private final AiDispatcherService aiDispatcherService;

    public DashboardController(TrainService trainService,
                               NetworkService networkService,
                               AiDispatcherService aiDispatcherService) {
        this.trainService       = trainService;
        this.networkService     = networkService;
        this.aiDispatcherService = aiDispatcherService;
    }

    /**
     * GET /api/dashboard — Full dashboard payload.
     */
    @GetMapping
    public Map<String, Object> getDashboard() {
        Map<String, Object> data = new LinkedHashMap<>();

        // Stats
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("activeTrains",  trainService.getActiveCount());
        stats.put("onTimeRate",    trainService.getOnTimeRate());
        stats.put("delayed",       trainService.getDelayedCount());
        stats.put("aiDecisions",   trainService.getAiDecisions());
        stats.put("runningTrains", trainService.getRunningCount());
        data.put("stats", stats);

        // Stations & Routes (for map rendering)
        data.put("stations", networkService.getStations());
        data.put("routes",   networkService.getRoutes());

        // Alerts
        data.put("alerts", getAlerts());

        // Board trains
        data.put("boardTrains", getBoardTrains());

        // AI actions — live from Java dispatcher
        data.put("aiActions", getAiActions());

        return data;
    }

    /**
     * GET /api/dashboard/stats — Just the live stats.
     */
    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("activeTrains",  trainService.getActiveCount());
        stats.put("onTimeRate",    trainService.getOnTimeRate());
        stats.put("delayed",       trainService.getDelayedCount());
        stats.put("aiDecisions",   trainService.getAiDecisions());
        stats.put("runningTrains", trainService.getRunningCount());
        return stats;
    }

    // ── Alerts — static reference scenarios ─────────────────────────────────
    private List<Alert> getAlerts() {
        return List.of(
            new Alert("ALT-002", "warning",      "Warning",
                "Weather delay — Mumbai corridor",
                "Strong crosswinds reducing max speed to 160 km/h on segments BOM-CCU.",
                "11 min ago", "Monitoring"),
            new Alert("ALT-011", "ai-resolving", "AI Resolving",
                "Cascade delay risk — New Delhi zone",
                "AI predicting 3 cascading delays from ICE 847 delay. Rerouting IC 204.",
                "5 min ago",  "AI Resolving"),
            new Alert("ALT-091", "resolved",     "Resolved",
                "Track maintenance overrun — Kolkata",
                "Maintenance completed. Track re-opened. 3 trains rescheduled by AI successfully.",
                "22 min ago", null),
            new Alert("ALT-045", "critical",     "Critical",
                "Signal failure — SIG-012",
                "Signal SIG-012 on segment HYD-AMD stuck on red. Emergency protocol triggered.",
                "2 min ago",  "Investigate"),
            new Alert("ALT-078", "info",         "Info",
                "Capacity threshold — Chennai",
                "Chennai nearing 90% platform capacity. Rerouting suggestions available.",
                "8 min ago",  "View Options")
        );
    }

    // ── Board trains ─────────────────────────────────────────────────────────
    private List<Map<String, Object>> getBoardTrains() {
        List<Map<String, Object>> board = new ArrayList<>();
        board.add(Map.of("name","ICE 847","chip","chip-ice","route","New Delhi → ...","depart","23:38","delay",14,"status","delayed"));
        board.add(Map.of("name","IC 204", "chip","chip-ic", "route","Bengaluru → ...",  "depart","23:42","delay",3, "status","delayed"));
        board.add(Map.of("name","ICE 72", "chip","chip-ice","route","Hamb. → ...", "depart","23:44","delay",0, "status","on-time"));
        board.add(Map.of("name","IC 501", "chip","chip-ic", "route","Münch. → ...","depart","23:48","delay",0, "status","on-time"));
        board.add(Map.of("name","RE 19",  "chip","chip-re", "route","Frankf. →...", "depart","23:51","delay",7, "status","delayed"));
        board.add(Map.of("name","ICE 85", "chip","chip-ice","route","Münch. → ...","depart","23:58","delay",0, "status","on-time"));
        return board;
    }

    // ── AI actions — live progress bars from dispatcher ──────────────────────
    private List<Map<String, Object>> getAiActions() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        return List.of(
            Map.of("text", "Recalculating <strong>ICE 847</strong> route via Pune...",          "progress", rnd.nextInt(60, 95)),
            Map.of("text", "Adjusting <strong>IC 204</strong> departure window...",                "progress", rnd.nextInt(30, 70)),
            Map.of("text", "Predicting cascade delays — <strong>Mumbai zone</strong>",            "progress", rnd.nextInt(75, 98)),
            Map.of("text", "Optimizing platform assignment — <strong>Hyderabad</strong>",           "progress", rnd.nextInt(20, 55))
        );
    }
}

