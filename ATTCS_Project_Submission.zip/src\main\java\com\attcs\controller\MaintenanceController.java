package com.attcs.controller;

import com.attcs.model.CapacitySegment;
import com.attcs.model.MaintenanceItem;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * REST API for maintenance, rescheduling, and capacity data.
 */
@RestController
@RequestMapping("/api")
public class MaintenanceController {

    // ── GET /api/maintenance ──
    @GetMapping("/maintenance")
    public List<MaintenanceItem> getMaintenance() {
        return List.of(
            new MaintenanceItem("Track Inspection — PNQ-LKO Segment",
                "Routine rail inspection and wear measurement", "2026-04-19", "scheduled", "scheduled"),
            new MaintenanceItem("Signal Repair — SIG-012",
                "Emergency repair of stuck signal at Hyderabad-Ahmedabad", "2026-04-18", "in-progress", "urgent"),
            new MaintenanceItem("Switch Mechanism — Kolkata Jct",
                "Preventive maintenance of junction switch #4", "2026-04-20", "scheduled", "scheduled"),
            new MaintenanceItem("Overhead Wire — Mumbai-Nagpur",
                "Catenary wire tension adjustment after storm", "2026-04-18", "in-progress", "in-progress"),
            new MaintenanceItem("Platform Resurfacing — Bengaluru P3",
                "Surface repair and marking renewal", "2026-04-17", "completed", "completed"),
            new MaintenanceItem("Brake System — ICE Fleet #8",
                "Scheduled brake pad replacement for ICE fleet unit 8", "2026-04-21", "scheduled", "scheduled"),
            new MaintenanceItem("Track Bed Stabilization — MAA-JAI",
                "Ballast tamping and realignment", "2026-04-22", "scheduled", "scheduled"),
            new MaintenanceItem("Signal Calibration — New Delhi South",
                "Full recalibration of 6 signals at New Delhi south junction", "2026-04-16", "completed", "completed")
        );
    }

    // ── GET /api/rescheduling ──
    @GetMapping("/rescheduling")
    public Map<String, Object> getRescheduling() {
        Map<String, Object> data = new LinkedHashMap<>();

        List<Map<String, String>> items = List.of(
            Map.of("train","ICE 847","detail","Original dep 23:24 → rescheduled to 23:38. Rerouted via Pune.","time","23:20"),
            Map.of("train","IC 204","detail","Departure adjusted by +3 min to avoid platform conflict at Bengaluru.","time","23:35"),
            Map.of("train","RE 19","detail","Held at Hyderabad for 4 min. Connection preserved for IC 501.","time","23:40"),
            Map.of("train","ICE 374","detail","Fast-tracked to express priority. ETA Chennai improved by 8 min.","time","23:15"),
            Map.of("train","IC 932","detail","Route changed: Bengaluru → Kolkata → Ahmedabad (avoiding Hyderabad congestion).","time","23:28"),
            Map.of("train","RE 42","detail","No changes needed. AI confirmed on-time status.","time","23:32"),
            Map.of("train","ICE 691","detail","Rerouted via Kolkata due to signal failure on direct New Delhi-Mumbai track.","time","23:10")
        );
        data.put("items", items);

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total", 17);
        stats.put("saved", "12 min");
        stats.put("cascade", 8);
        stats.put("confidence", "94.2%");
        stats.put("overrides", 2);
        data.put("stats", stats);

        return data;
    }

    // ── GET /api/capacity ──
    @GetMapping("/capacity")
    public Map<String, Object> getCapacity() {
        Map<String, Object> data = new LinkedHashMap<>();

        List<CapacitySegment> segments = List.of(
            new CapacitySegment("New Delhi", 78),
            new CapacitySegment("Mumbai", 65),
            new CapacitySegment("Chennai", 91),
            new CapacitySegment("Hyderabad", 84),
            new CapacitySegment("Bengaluru", 58),
            new CapacitySegment("Kolkata", 72),
            new CapacitySegment("Ahmedabad", 45),
            new CapacitySegment("Pune", 52),
            new CapacitySegment("Jaipur", 38),
            new CapacitySegment("DEL-BOM Track", 70),
            new CapacitySegment("HYD-AMD Track", 88),
            new CapacitySegment("BOM-CCU Track", 55)
        );
        data.put("segments", segments);

        // 24hr chart data
        List<Double> chartData = new ArrayList<>();
        Random random = new Random(42); // Fixed seed for consistency
        for (int i = 0; i < 24; i++) {
            double base = 30 + Math.sin(i / 24.0 * Math.PI * 2 - Math.PI / 2) * 35;
            double value = Math.max(10, Math.min(95, base + (random.nextDouble() - 0.5) * 20));
            chartData.add(Math.round(value * 10.0) / 10.0);
        }
        data.put("chartData", chartData);

        return data;
    }
}
