package com.attcs.controller;

import com.attcs.model.Signal;
import com.attcs.service.SignalService;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * REST API for signal grid and signal control.
 */
@RestController
@RequestMapping("/api/signals")
public class SignalController {

    private final SignalService signalService;

    public SignalController(SignalService signalService) {
        this.signalService = signalService;
    }

    /**
     * GET /api/signals — All signals with statistics.
     */
    @GetMapping
    public Map<String, Object> getSignals() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("signals", signalService.getAllSignals());
        result.put("stats", signalService.getStats());
        return result;
    }

    /**
     * POST /api/signals/{id}/change — Change a signal's state.
     * Body: { "state": "green" | "yellow" | "red" | "blue" }
     */
    @PostMapping("/{id}/change")
    public Map<String, Object> changeSignal(@PathVariable String id, @RequestBody Map<String, String> body) {
        String newState = body.get("state");
        boolean ok = signalService.changeSignalState(id, newState);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("success", ok);
        response.put("signalId", id);
        response.put("newState", newState);
        if (ok) {
            response.put("message", "Signal " + id + " changed to " + newState.toUpperCase());
        } else {
            response.put("message", "Signal " + id + " not found");
        }
        return response;
    }
}
