package com.attcs.controller;

import com.attcs.service.AiDispatcherService;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * REST API for AI dispatch queue and decision log — powered by native Java AI engine.
 */
@RestController
@RequestMapping("/api/dispatch")
public class DispatchController {

    private final AiDispatcherService aiDispatcherService;

    public DispatchController(AiDispatcherService aiDispatcherService) {
        this.aiDispatcherService = aiDispatcherService;
    }

    /**
     * GET /api/dispatch — Live dispatch queue + timestamped decision log.
     */
    @GetMapping
    public Map<String, Object> getDispatch() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("queue",       aiDispatcherService.getDecisions());
        data.put("decisionLog", aiDispatcherService.getDecisionLog());
        return data;
    }
}
