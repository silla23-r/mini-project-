package com.attcs.model;

/**
 * Track/station capacity segment with utilization data.
 */
public class CapacitySegment {
    private String name;
    private int usage;  // percentage 0-100

    public CapacitySegment() {}

    public CapacitySegment(String name, int usage) {
        this.name = name;
        this.usage = usage;
    }

    // ── Getters & Setters ──
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getUsage() { return usage; }
    public void setUsage(int usage) { this.usage = usage; }
}
