package com.attcs.model;

import jakarta.persistence.*;

/**
 * Active train on the network.
 */
@Entity
public class Train {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String type;      // "ice", "ic", "re"
    private String route;     // Display string e.g. "New Delhi → Mumbai"
    private String fromId;
    private String toId;
    private double progress;  // 0.0 to 1.0
    private String status;    // "on-time", "delayed", "stopped"
    private int speed;        // km/h
    private int delay;        // minutes
    private double x;         // Current map X (0..1)
    private double y;         // Current map Y (0..1)
    private String nextStation;
    private String eta;
    private String departTime;

    public Train() {}

    // ── Getters & Setters ──
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getRoute() { return route; }
    public void setRoute(String route) { this.route = route; }
    public String getFromId() { return fromId; }
    public void setFromId(String fromId) { this.fromId = fromId; }
    public String getToId() { return toId; }
    public void setToId(String toId) { this.toId = toId; }
    public double getProgress() { return progress; }
    public void setProgress(double progress) { this.progress = progress; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getSpeed() { return speed; }
    public void setSpeed(int speed) { this.speed = speed; }
    public int getDelay() { return delay; }
    public void setDelay(int delay) { this.delay = delay; }
    public double getX() { return x; }
    public void setX(double x) { this.x = x; }
    public double getY() { return y; }
    public void setY(double y) { this.y = y; }
    public String getNextStation() { return nextStation; }
    public void setNextStation(String nextStation) { this.nextStation = nextStation; }
    public String getEta() { return eta; }
    public void setEta(String eta) { this.eta = eta; }
    public String getDepartTime() { return departTime; }
    public void setDepartTime(String departTime) { this.departTime = departTime; }
}
