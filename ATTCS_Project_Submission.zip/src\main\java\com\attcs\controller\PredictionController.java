package com.attcs.controller;

import com.attcs.model.Prediction;
import com.attcs.service.AiPredictorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST API for AI predictions — powered by native Java AI engine.
 */
@RestController
@RequestMapping("/api/predictions")
public class PredictionController {

    private final AiPredictorService aiPredictorService;

    public PredictionController(AiPredictorService aiPredictorService) {
        this.aiPredictorService = aiPredictorService;
    }

    /**
     * GET /api/predictions — AI-generated predictions from native Java engine.
     * Results vary per call based on time-of-day risk and probabilistic scoring.
     */
    @GetMapping
    public List<Prediction> getPredictions() {
        return aiPredictorService.generatePredictions();
    }
}
