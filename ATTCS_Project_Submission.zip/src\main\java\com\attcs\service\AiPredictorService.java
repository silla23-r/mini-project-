package com.attcs.service;

import com.attcs.model.Prediction;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * ═══════════════════════════════════════════════════
 * ATTCS AI — Delay & Congestion Predictor (Pure Java)
 * Pattern-based probabilistic prediction engine.
 * Mirrors: ai-engine/ai_predictor.py
 * ═══════════════════════════════════════════════════
 */
@Service
public class AiPredictorService {

    // Historical delay risk per station (learned patterns) — same as Python
    private static final Map<String, Double> STATION_DELAY_RISK = new LinkedHashMap<>();
    static {
        STATION_DELAY_RISK.put("kolkata",   0.35);
        STATION_DELAY_RISK.put("hyderabad",  0.30);
        STATION_DELAY_RISK.put("chennai",     0.25);
        STATION_DELAY_RISK.put("mumbai",    0.28);
        STATION_DELAY_RISK.put("new_delhi",     0.20);
        STATION_DELAY_RISK.put("bengaluru",    0.22);
        STATION_DELAY_RISK.put("ahmedabad",  0.15);
        STATION_DELAY_RISK.put("jaipur",  0.18);
        STATION_DELAY_RISK.put("pune",    0.12);
        STATION_DELAY_RISK.put("surat", 0.14);
        STATION_DELAY_RISK.put("lucknow",    0.10);
        STATION_DELAY_RISK.put("nagpur",     0.08);
    }

    // Weather scenarios — same as Python
    private static final List<String[]> WEATHER_PATTERNS = List.of(
        new String[]{"Mumbai-Nagpur corridor",         "0.91", "storms"},
        new String[]{"Alpine approaches (Chennai)",    "0.45", "fog"},
        new String[]{"Rhine valley (Bengaluru-Hyderabad)", "0.30", "wind"},
        new String[]{"Northern plains",                "0.65", "ice"}
    );

    private static final String[] TRAIN_NAMES = {
        "ICE 1523", "IC 932", "ICE 374", "RE 3", "ICE 691", "ICE 847", "IC 204"
    };

    /**
     * Generate AI predictions using pattern analysis.
     * Called on every request — outputs vary by time of day + random factors.
     */
    public List<Prediction> generatePredictions() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        double timeFactor = timeBasedRiskFactor();
        List<Prediction> predictions = new ArrayList<>();

        // ── 1. Delay predictions: top 2 high-risk stations ─────────────────
        List<Map.Entry<String, Double>> sortedRisk = new ArrayList<>(STATION_DELAY_RISK.entrySet());
        sortedRisk.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        for (int i = 0; i < 2; i++) {
            Map.Entry<String, Double> entry = sortedRisk.get(i);
            String stationId  = entry.getKey();
            double baseRisk   = entry.getValue();
            double risk       = Math.min(0.99, baseRisk * timeFactor);
            int    confidence = calculateConfidence(risk, rnd.nextInt(40, 101));
            int    delayMin   = (int)(risk * 30) + rnd.nextInt(2, 9);
            String level      = confidence >= 70 ? "high" : confidence >= 50 ? "medium" : "low";
            String train      = TRAIN_NAMES[rnd.nextInt(TRAIN_NAMES.length)];
            String stationTitle = capitalize(stationId);

            predictions.add(new Prediction(
                "delay", "Delay", confidence,
                train + " likely delayed at " + stationTitle,
                "Pattern analysis shows " + confidence + "% probability of " +
                delayMin + "–" + (delayMin + 4) + " minute delay due to converging " +
                "traffic at " + stationTitle + " junction during " +
                (timeFactor > 1 ? "peak" : "current") + " hours. " +
                "AI model analyzed " + rnd.nextInt(1200, 5001) + " historical patterns.",
                level, confidence
            ));
        }

        // ── 2. Congestion prediction ────────────────────────────────────────
        double congRisk = Math.min(0.99, 0.70 * timeFactor);
        int congConf    = calculateConfidence(congRisk, 60);
        predictions.add(new Prediction(
            "congestion", "Congestion", congConf,
            "Hyderabad corridor congestion expected",
            "Historical data + current load indicates congestion buildup on " +
            "Hyderabad-Ahmedabad segment. AI model confidence: " + congConf + "%. " +
            "Recommend speed adjustment and pre-emptive rerouting.",
            congConf >= 70 ? "high" : "medium", congConf
        ));

        // ── 3. Weather prediction ───────────────────────────────────────────
        String[] weather = WEATHER_PATTERNS.get(rnd.nextInt(WEATHER_PATTERNS.size()));
        String wRegion   = weather[0];
        double wRisk     = Double.parseDouble(weather[1]);
        String wType     = weather[2];
        int wConf        = calculateConfidence(wRisk, 80);
        predictions.add(new Prediction(
            "weather", "Weather", wConf,
            "Severe " + wType + " — " + wRegion,
            "Weather AI model forecasts " + wType + " in " + wRegion + ". " +
            "Speed restrictions recommended. Confidence: " + wConf + "%. " +
            "Data sources: 3 weather APIs + satellite imagery analysis.",
            wConf >= 70 ? "high" : "medium", wConf
        ));

        // ── 4. Maintenance prediction ───────────────────────────────────────
        int mConf = rnd.nextInt(55, 76);
        int sensors = rnd.nextInt(500, 2001);
        predictions.add(new Prediction(
            "maintenance", "Maintenance", mConf,
            "Track wear detected — Pune segment",
            "Vibration sensors indicate accelerated wear on PNQ-LKO segment. " +
            "Preventive maintenance recommended within 72 hours. " +
            "AI analysis of " + sensors + " sensor readings.",
            "medium", mConf
        ));

        // ── 5. Platform overload prediction ────────────────────────────────
        int pConf    = calculateConfidence(0.82, 70);
        int rolling  = rnd.nextInt(30, 91);
        predictions.add(new Prediction(
            "congestion", "Congestion", pConf,
            "Chennai platform overload",
            "AI suggests Chennai main station will hit 95% capacity. " +
            "Recommend pre-emptive rerouting of 2 regional trains. " +
            "Prediction based on " + rolling + " day rolling average.",
            pConf >= 70 ? "high" : "medium", pConf
        ));

        return predictions;
    }

    // ── Peak-hour risk multiplier (same logic as Python) ─────────────────────

    private double timeBasedRiskFactor() {
        int hour = LocalTime.now().getHour();
        if ((hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 19)) return 1.4; // Peak
        if (hour >= 10 && hour <= 15) return 1.0;                               // Normal
        return 0.6;                                                              // Off-peak
    }

    // ── Confidence calculation with Gaussian-style noise ─────────────────────

    private int calculateConfidence(double baseRisk, int dataPoints) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        // Gaussian approximation using two uniform randoms (Box-Muller lite)
        double noise     = (rnd.nextDouble() - 0.5) * 0.10;
        double rawConf   = baseRisk + noise;
        int    confidence = (int) Math.round(Math.max(20, Math.min(99, rawConf * 100)));
        double dataFactor = Math.min(1.0, dataPoints / 100.0);
        return (int)(confidence * dataFactor + (1 - dataFactor) * 50);
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
