package com.attcs.controller;

import com.attcs.model.Train;
import com.attcs.service.TrainService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST API for train positions and tracking.
 */
@RestController
@RequestMapping("/api/trains")
public class TrainController {

    private final TrainService trainService;

    public TrainController(TrainService trainService) {
        this.trainService = trainService;
    }

    /**
     * GET /api/trains — All active trains with live positions.
     */
    @GetMapping
    public List<Train> getAllTrains() {
        return trainService.getAllTrains();
    }

    /**
     * GET /api/trains/{id} — Single train detail.
     */
    @GetMapping("/{id}")
    public Train getTrain(@PathVariable String id) {
        return trainService.findTrain(id);
    }
}
