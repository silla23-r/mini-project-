package com.attcs.service;

import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * ═══════════════════════════════════════════════════
 * ATTCS AI — Rescheduling Engine (Pure Java)
 * Intelligent delay recovery and schedule optimization.
 * Mirrors: ai-engine/ai_rescheduler.py
 * ═══════════════════════════════════════════════════
 */
@Service
public class AiReschedulerService {

    /**
     * Generate AI rescheduling results.
     * Stats (confidence, overrides) vary per call.
     */
    public Map<String, Object> generateSchedule() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();

        List<Map<String, Object>> items = new ArrayList<>();
        items.add(item("ICE 847", "Original dep 23:24 → rescheduled to 23:38. Rerouted via Pune.",       "23:20", "Rerouting",           8));
        items.add(item("IC 204",  "Departure adjusted by +3 min to avoid platform conflict at Bengaluru.",        "23:35", "Platform swap",        3));
        items.add(item("RE 19",   "Held at Hyderabad for 4 min. Connection preserved for IC 501.",           "23:40", "Connection hold",      0));
        items.add(item("ICE 374", "Fast-tracked to express priority. ETA Chennai improved by 8 min.",        "23:15", "Priority boost",       8));
        items.add(item("IC 932",  "Route changed: Bengaluru → Kolkata → Ahmedabad (avoiding Hyderabad congestion).","23:28","Congestion avoidance",15));
        items.add(item("RE 42",   "No changes needed. AI confirmed on-time status.",                          "23:32", "Verified OK",          0));
        items.add(item("ICE 691", "Rerouted via Kolkata due to signal failure on direct New Delhi-Mumbai track.","23:10","Emergency reroute",   20));

        int totalSaved       = items.stream().mapToInt(i -> (int) i.get("delay_saved")).sum();
        int cascadePrevented = (int) items.stream().filter(i -> (int) i.get("delay_saved") > 5).count();
        double confidence    = Math.round((90 + rnd.nextDouble() * 8) * 10.0) / 10.0;
        int overrides        = rnd.nextInt(1, 4);

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total",      items.size());
        stats.put("saved",      totalSaved + " min");
        stats.put("cascade",    cascadePrevented);
        stats.put("confidence", confidence + "%");
        stats.put("overrides",  overrides);

        // Strip internal field before returning
        items.forEach(i -> i.remove("delay_saved"));

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("items",     items);
        result.put("stats",     stats);
        result.put("ai_engine", "java");
        return result;
    }

    private Map<String, Object> item(String train, String detail, String time,
                                      String aiAction, int delaySaved) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("train",       train);
        m.put("detail",      detail);
        m.put("time",        time);
        m.put("ai_action",   aiAction);
        m.put("delay_saved", delaySaved);
        return m;
    }
}
