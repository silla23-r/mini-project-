package com.attcs.service;

import com.attcs.model.Route;
import com.attcs.model.Station;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages the static rail network topology — stations and route segments.
 */
@Service
public class NetworkService {

    private final List<Station> stations = new ArrayList<>();
    private final List<Route> routes = new ArrayList<>();

    @PostConstruct
    public void init() {
        // ── Stations (same as original JS) ──
        stations.add(new Station("new_delhi",     "New Delhi",      0.65, 0.18));
        stations.add(new Station("mumbai",    "Mumbai",      0.45, 0.10));
        stations.add(new Station("chennai",     "Chennai",      0.60, 0.82));
        stations.add(new Station("hyderabad",  "Hyderabad",    0.35, 0.55));
        stations.add(new Station("bengaluru",    "Bengaluru",         0.22, 0.45));
        stations.add(new Station("kolkata",   "Kolkata",     0.42, 0.28));
        stations.add(new Station("ahmedabad",  "Ahmedabad",    0.40, 0.72));
        stations.add(new Station("pune",    "Pune",      0.62, 0.35));
        stations.add(new Station("jaipur",  "Jaipur",     0.55, 0.62));
        stations.add(new Station("lucknow",    "Lucknow",      0.78, 0.38));
        stations.add(new Station("surat", "Surat",   0.18, 0.40));
        stations.add(new Station("nagpur",     "Nagpur",       0.30, 0.15));

        // ── Routes (same as original JS) ──
        routes.add(new Route("new_delhi",   "mumbai",    "ice", 286));
        routes.add(new Route("new_delhi",   "kolkata",   "ice", 253));
        routes.add(new Route("new_delhi",   "pune",    "ice", 187));
        routes.add(new Route("new_delhi",   "lucknow",    "ic",  193));
        routes.add(new Route("mumbai",  "kolkata",   "ice", 150));
        routes.add(new Route("mumbai",  "nagpur",     "ic",  119));
        routes.add(new Route("kolkata", "bengaluru",    "ice", 284));
        routes.add(new Route("kolkata", "hyderabad",  "ice", 355));
        routes.add(new Route("bengaluru",  "hyderabad",  "ice", 189));
        routes.add(new Route("bengaluru",  "surat", "ic",  40));
        routes.add(new Route("hyderabad","ahmedabad",   "ice", 210));
        routes.add(new Route("hyderabad","jaipur",  "ice", 226));
        routes.add(new Route("ahmedabad","chennai",     "ice", 234));
        routes.add(new Route("jaipur","chennai",     "ice", 171));
        routes.add(new Route("jaipur","pune",    "ic",  278));
        routes.add(new Route("pune",  "lucknow",    "re",  120));
        routes.add(new Route("nagpur",   "surat", "re",  310));
        routes.add(new Route("kolkata", "pune",    "ic",  254));
    }

    public List<Station> getStations() {
        return Collections.unmodifiableList(stations);
    }

    public List<Route> getRoutes() {
        return Collections.unmodifiableList(routes);
    }

    public Station findStation(String id) {
        return stations.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Route findRoute(String fromId, String toId) {
        return routes.stream()
                .filter(r -> (r.getFrom().equals(fromId) && r.getTo().equals(toId))
                          || (r.getFrom().equals(toId)   && r.getTo().equals(fromId)))
                .findFirst()
                .orElse(null);
    }
}
