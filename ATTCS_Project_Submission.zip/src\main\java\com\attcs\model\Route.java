package com.attcs.model;

/**
 * Route segment connecting two stations.
 */
public class Route {
    private String from;
    private String to;
    private String type;  // "ice", "ic", "re"
    private int distance;  // km

    public Route() {}

    public Route(String from, String to, String type, int distance) {
        this.from = from;
        this.to = to;
        this.type = type;
        this.distance = distance;
    }

    // ── Getters & Setters ──
    public String getFrom() { return from; }
    public void setFrom(String from) { this.from = from; }
    public String getTo() { return to; }
    public void setTo(String to) { this.to = to; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public int getDistance() { return distance; }
    public void setDistance(int distance) { this.distance = distance; }
}
