package com.attcs.controller;

import com.attcs.service.AiProxyService;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * REST API for AI-powered route optimization.
 */
@RestController
@RequestMapping("/api/routes")
public class RouteController {

    private final AiProxyService aiProxyService;

    public RouteController(AiProxyService aiProxyService) {
        this.aiProxyService = aiProxyService;
    }

    /**
     * POST /api/routes/optimize
     * Body: { "origin": "new_delhi", "destination": "chennai", "priority": "fastest" }
     */
    @PostMapping("/optimize")
    public Map<String, Object> optimizeRoute(@RequestBody Map<String, String> body) {
        String origin = body.get("origin");
        String destination = body.get("destination");
        String priority = body.get("priority");

        Map<String, Object> result = new LinkedHashMap<>();

        if (origin != null && origin.equals(destination)) {
            result.put("error", "Origin and destination cannot be the same");
            return result;
        }

        List<Map<String, Object>> routes = aiProxyService.optimizeRoute(origin, destination, priority);
        result.put("origin", origin);
        result.put("destination", destination);
        result.put("priority", priority);
        result.put("routes", routes);
        return result;
    }
}
