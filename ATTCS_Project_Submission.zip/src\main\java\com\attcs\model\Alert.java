package com.attcs.model;

/**
 * AI alert/notification.
 */
public class Alert {
    private String id;
    private String type;        // "warning", "critical", "resolved", "info", "ai-resolving"
    private String badgeLabel;
    private String title;
    private String desc;
    private String time;
    private String action;      // nullable

    public Alert() {}

    public Alert(String id, String type, String badgeLabel, String title, String desc, String time, String action) {
        this.id = id;
        this.type = type;
        this.badgeLabel = badgeLabel;
        this.title = title;
        this.desc = desc;
        this.time = time;
        this.action = action;
    }

    // ── Getters & Setters ──
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getBadgeLabel() { return badgeLabel; }
    public void setBadgeLabel(String badgeLabel) { this.badgeLabel = badgeLabel; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDesc() { return desc; }
    public void setDesc(String desc) { this.desc = desc; }
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
}
