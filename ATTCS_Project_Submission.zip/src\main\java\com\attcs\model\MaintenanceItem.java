package com.attcs.model;

/**
 * Maintenance schedule item.
 */
public class MaintenanceItem {
    private String title;
    private String desc;
    private String date;
    private String status;   // "scheduled", "in-progress", "completed"
    private String type;     // "scheduled", "urgent", "in-progress", "completed"

    public MaintenanceItem() {}

    public MaintenanceItem(String title, String desc, String date, String status, String type) {
        this.title = title;
        this.desc = desc;
        this.date = date;
        this.status = status;
        this.type = type;
    }

    // ── Getters & Setters ──
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDesc() { return desc; }
    public void setDesc(String desc) { this.desc = desc; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
